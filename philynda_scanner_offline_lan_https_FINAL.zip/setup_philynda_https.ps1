#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

# ============================================================
# PHILYNDA LOCAL HTTPS SETUP - MIGRATION SAFE / XAMPP SAFE
#
# This version deliberately uses an explicit OpenSSL configuration
# for the Root CA. Some XAMPP/OpenSSL installations fail when the
# default openssl.cnf cannot be found or is incompatible.
# ============================================================

$Xampp = 'C:\xampp'
$Apache = Join-Path $Xampp 'apache'
$ApacheBin = Join-Path $Apache 'bin'
$Httpd = Join-Path $ApacheBin 'httpd.exe'
$OpenSSL = Join-Path $ApacheBin 'openssl.exe'
$ApacheConf = Join-Path $Apache 'conf'
$HttpdConf = Join-Path $ApacheConf 'httpd.conf'
$ExtraDir = Join-Path $ApacheConf 'extra'
$VhostConf = Join-Path $ExtraDir 'httpd-philynda-ssl.conf'

# Permanent CA store on this PC.
$PermanentDir = 'C:\ProgramData\Philynda\certificates'
$CaKey = Join-Path $PermanentDir 'philynda-root-ca.key'
$CaCrt = Join-Path $PermanentDir 'philynda-root-ca.crt'
$CaConf = Join-Path $PermanentDir 'philynda-ca-openssl.cnf'

# Portable CA backup folder.
$PortableDir = Join-Path $PSScriptRoot 'philynda-ca-backup'
$PortableCaKey = Join-Path $PortableDir 'philynda-root-ca.key'
$PortableCaCrt = Join-Path $PortableDir 'philynda-root-ca.crt'

# Per-PC server certificate files.
$SslDir = Join-Path $ApacheConf 'philynda-ssl'
$ServerKey = Join-Path $SslDir 'philynda-server.key'
$ServerCrt = Join-Path $SslDir 'philynda-server.crt'
$ServerCsr = Join-Path $SslDir 'philynda-server.csr'
$ServerConf = Join-Path $SslDir 'server-openssl.cnf'
$OpenSSLLog = Join-Path $SslDir 'openssl-last-error.log'
$Backup = Join-Path $ApacheConf 'httpd.conf.philynda-backup'

Write-Host '=== Philynda local HTTPS setup ===' -ForegroundColor Cyan
Write-Host '=== XAMPP/OpenSSL compatible certificate generation ===' -ForegroundColor Cyan

if (-not (Test-Path $Httpd)) { throw "Apache was not found at $Httpd" }
if (-not (Test-Path $OpenSSL)) { throw "OpenSSL was not found at $OpenSSL" }
if (-not (Test-Path $HttpdConf)) { throw "Apache httpd.conf was not found at $HttpdConf" }

function Test-PrivateIPv4([string]$ip) {
    if ($ip -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { return $false }
    $p = $ip.Split('.') | ForEach-Object { [int]$_ }
    if ($p.Count -ne 4) { return $false }
    if (($p | Where-Object { $_ -lt 0 -or $_ -gt 255 }).Count -gt 0) { return $false }
    if ($p[0] -eq 10) { return $true }
    if ($p[0] -eq 172 -and $p[1] -ge 16 -and $p[1] -le 31) { return $true }
    if ($p[0] -eq 192 -and $p[1] -eq 168) { return $true }
    return $false
}

function Get-LanIp {
    $candidates = @()
    try {
        $candidates += Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
            Where-Object {
                $_.IPAddress -notlike '127.*' -and
                $_.IPAddress -notlike '169.254.*' -and
                (Test-PrivateIPv4 $_.IPAddress)
            } |
            Select-Object IPAddress,InterfaceAlias,PrefixLength
    } catch {
        $raw = ipconfig | Out-String
        foreach ($m in [regex]::Matches($raw, '(?im)(?:IPv4 Address|IPv4-Adresse)[^:]*:\s*([0-9.]+)')) {
            if (Test-PrivateIPv4 $m.Groups[1].Value) {
                $candidates += [pscustomobject]@{
                    IPAddress=$m.Groups[1].Value
                    InterfaceAlias='ipconfig'
                    PrefixLength=24
                }
            }
        }
    }

    if (-not $candidates -or $candidates.Count -eq 0) {
        throw 'No private LAN IPv4 address was found. Connect this PC to the local Wi-Fi/Ethernet network and run the setup again.'
    }

    $lan = $candidates |
        Sort-Object @{Expression={ if ($_.InterfaceAlias -match 'Wi-?Fi|Wireless|Ethernet|LAN') {0} else {1} }}, InterfaceAlias |
        Select-Object -First 1

    return $lan.IPAddress
}

function Invoke-OpenSSL([string[]]$Arguments, [string]$Description) {
    if (Test-Path $OpenSSLLog) { Remove-Item $OpenSSLLog -Force -ErrorAction SilentlyContinue }

    Write-Host "OpenSSL: $Description" -ForegroundColor DarkCyan

    # Do not invoke OpenSSL with PowerShell's '&' here. Windows PowerShell 5.1
    # can surface harmless OpenSSL STDERR progress (for example RSA key
    # generation text) as a NativeCommandError when ErrorActionPreference is
    # Stop. We instead launch the process directly and judge success only by
    # its real exit code.
    $oldOpenSSLConf = $env:OPENSSL_CONF
    $env:OPENSSL_CONF = $null

    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $OpenSSL
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true

        # The paths used by this installer contain no spaces in normal XAMPP
        # installations, but quote arguments that contain whitespace or quotes.
        $psi.Arguments = ($Arguments | ForEach-Object {
            $arg = [string]$_
            if ($arg -match '[\s"]') {
                '"' + $arg.Replace('\','\\').Replace('"','\"') + '"'
            } else {
                $arg
            }
        }) -join ' '

        $proc = New-Object System.Diagnostics.Process
        $proc.StartInfo = $psi

        if (-not $proc.Start()) {
            throw "Windows could not start OpenSSL at $OpenSSL"
        }

        $stdout = $proc.StandardOutput.ReadToEnd()
        $stderr = $proc.StandardError.ReadToEnd()
        $proc.WaitForExit()
        $code = $proc.ExitCode

        $combined = @(
            "[$Description] Exit code: $code",
            '--- STDOUT ---',
            $stdout,
            '--- STDERR ---',
            $stderr
        ) -join "`r`n"
        Set-Content -Path $OpenSSLLog -Value $combined -Encoding utf8

        if ($code -ne 0) {
            throw "${Description} failed.`r`n`r`nOpenSSL output:`r`n$combined`r`n`r`nSee: $OpenSSLLog"
        }
    } finally {
        $env:OPENSSL_CONF = $oldOpenSSLConf
    }
}

$LanIp = Get-LanIp
Write-Host "Detected PC LAN IP: $LanIp" -ForegroundColor Green

foreach ($dir in @($PermanentDir,$SslDir,$PortableDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

if (-not (Test-Path $Backup)) {
    Copy-Item $HttpdConf $Backup -Force
    Write-Host "Backed up httpd.conf to $Backup" -ForegroundColor Yellow
}

# ------------------------------------------------------------
# PERMANENT ROOT CA
# ------------------------------------------------------------
$CaCreatedNow = $false

if ((-not (Test-Path $CaKey)) -or (-not (Test-Path $CaCrt))) {
    if ((Test-Path $PortableCaKey) -and (Test-Path $PortableCaCrt)) {
        Write-Host 'Importing the existing Philynda Root CA from the portable backup...' -ForegroundColor Cyan
        Copy-Item $PortableCaKey $CaKey -Force
        Copy-Item $PortableCaCrt $CaCrt -Force
    } else {
        Write-Host 'No existing Philynda Root CA was found. Creating it now.' -ForegroundColor Yellow
        Write-Host 'The explicit OpenSSL config below avoids the common XAMPP config-file error.' -ForegroundColor Yellow

        $caConfig = @"
[ req ]
 distinguished_name = req_distinguished_name
 x509_extensions = v3_ca
 prompt = no

[ req_distinguished_name ]
 C = GH
 O = Philynda
 CN = Philynda Local Root CA

[ v3_ca ]
 subjectKeyIdentifier = hash
 authorityKeyIdentifier = keyid:always,issuer
 basicConstraints = critical, CA:true, pathlen:1
 keyUsage = critical, keyCertSign, cRLSign
"@
        Set-Content -Path $CaConf -Value $caConfig -Encoding ascii

        Invoke-OpenSSL @('version') 'Checking OpenSSL'

        Invoke-OpenSSL @('genrsa','-out',$CaKey,'4096') 'Creating the Philynda Root CA private key'

        # -nodes works on old and new OpenSSL versions. If an OpenSSL 3 build
        # rejects the operation, try the same operation with -noenc.
        try {
            Invoke-OpenSSL @('req','-x509','-new','-nodes','-sha256','-days','3650','-key',$CaKey,'-out',$CaCrt,'-config',$CaConf,'-extensions','v3_ca','-subj','/C=GH/O=Philynda/CN=Philynda Local Root CA','-batch') 'Creating the Philynda Root CA certificate'
        } catch {
            $firstError = $_.Exception.Message
            Write-Host 'The first CA certificate command failed. Retrying with OpenSSL 3 -noenc syntax...' -ForegroundColor Yellow
            try {
                Invoke-OpenSSL @('req','-x509','-new','-noenc','-sha256','-days','3650','-key',$CaKey,'-out',$CaCrt,'-config',$CaConf,'-extensions','v3_ca','-subj','/C=GH/O=Philynda/CN=Philynda Local Root CA','-batch') 'Creating the Philynda Root CA certificate (OpenSSL 3 retry)'
            } catch {
                throw "$firstError`r`n`r`nThe OpenSSL 3 retry also failed.`r`n$($_.Exception.Message)"
            }
        }

        $CaCreatedNow = $true
    }
}

if (-not (Test-Path $CaKey)) { throw "Root CA private key is missing: $CaKey" }
if (-not (Test-Path $CaCrt)) { throw "Root CA certificate is missing: $CaCrt" }

# ------------------------------------------------------------
# GENERATE NEW SERVER CERTIFICATE FOR CURRENT PC LAN IP
# ------------------------------------------------------------
@"
[ req ]
 distinguished_name = req_distinguished_name
 req_extensions = req_ext
 prompt = no

[ req_distinguished_name ]
 C = GH
 O = Philynda
 CN = $LanIp

[ req_ext ]
 subjectAltName = @alt_names
 keyUsage = critical, digitalSignature, keyEncipherment
 extendedKeyUsage = serverAuth
 basicConstraints = critical, CA:false
 subjectKeyIdentifier = hash

[ alt_names ]
 IP.1 = $LanIp
 IP.2 = 127.0.0.1
 DNS.1 = localhost
"@ | Set-Content -Path $ServerConf -Encoding ascii

Remove-Item $ServerKey,$ServerCrt,$ServerCsr -Force -ErrorAction SilentlyContinue

Invoke-OpenSSL @('genrsa','-out',$ServerKey,'2048') 'Creating the PC HTTPS private key'
Invoke-OpenSSL @('req','-new','-key',$ServerKey,'-out',$ServerCsr,'-config',$ServerConf,'-batch') 'Creating the PC HTTPS certificate request'
Invoke-OpenSSL @('x509','-req','-in',$ServerCsr,'-CA',$CaCrt,'-CAkey',$CaKey,'-CAcreateserial','-out',$ServerCrt,'-days','825','-sha256','-extensions','req_ext','-extfile',$ServerConf) 'Signing the PC HTTPS certificate'

Remove-Item $ServerCsr -Force -ErrorAction SilentlyContinue
$serialPath = Join-Path $SslDir 'philynda-server.srl'
Remove-Item $serialPath -Force -ErrorAction SilentlyContinue

# Verify that the CA and server certificate can actually be read.
Invoke-OpenSSL @('x509','-in',$CaCrt,'-noout','-subject','-issuer','-dates') 'Verifying the Philynda Root CA certificate'
Invoke-OpenSSL @('x509','-in',$ServerCrt,'-noout','-subject','-issuer','-ext','subjectAltName') 'Verifying the PC HTTPS certificate'

# ------------------------------------------------------------
# APACHE MODULES + 8443 VHOST
# ------------------------------------------------------------
$conf = Get-Content -Raw -Path $HttpdConf

if ($conf -notmatch '(?m)^\s*LoadModule\s+socache_shmcb_module\s+modules/mod_socache_shmcb\.so\s*$') {
    $conf = $conf -replace '(?m)^\s*#\s*LoadModule\s+socache_shmcb_module\s+modules/mod_socache_shmcb\.so\s*$', 'LoadModule socache_shmcb_module modules/mod_socache_shmcb.so'
}
if ($conf -notmatch '(?m)^\s*LoadModule\s+ssl_module\s+modules/mod_ssl\.so\s*$') {
    $conf = $conf -replace '(?m)^\s*#\s*LoadModule\s+ssl_module\s+modules/mod_ssl\.so\s*$', 'LoadModule ssl_module modules/mod_ssl.so'
}
if ($conf -notmatch '(?m)^\s*LoadModule\s+ssl_module\s+modules/mod_ssl\.so\s*$') {
    $conf += "`r`nLoadModule ssl_module modules/mod_ssl.so`r`n"
}
if ($conf -notmatch '(?m)^\s*LoadModule\s+socache_shmcb_module\s+modules/mod_socache_shmcb\.so\s*$') {
    $conf += "`r`nLoadModule socache_shmcb_module modules/mod_socache_shmcb.so`r`n"
}
if ($conf -notmatch '(?m)^\s*Listen\s+8443\s*$') {
    $conf += "`r`nListen 8443`r`n"
}
$includeLine = 'Include conf/extra/httpd-philynda-ssl.conf'
if ($conf -notmatch '(?m)^\s*Include\s+conf/extra/httpd-philynda-ssl\.conf\s*$') {
    $conf += "`r`n$includeLine`r`n"
}
Set-Content -Path $HttpdConf -Value $conf -Encoding ascii

$vhost = @"
# Philynda local HTTPS scanner - generated by setup_philynda_https.ps1
<VirtualHost *:8443>
    ServerName $LanIp
    DocumentRoot "C:/xampp/htdocs"

    <Directory "C:/xampp/htdocs">
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    SSLEngine on
    SSLCertificateFile "C:/xampp/apache/conf/philynda-ssl/philynda-server.crt"
    SSLCertificateKeyFile "C:/xampp/apache/conf/philynda-ssl/philynda-server.key"
    SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
    SSLSessionCache "shmcb:C:/xampp/apache/logs/ssl_scache(512000)"
    SSLSessionCacheTimeout 300

    ErrorLog "C:/xampp/apache/logs/philynda-ssl-error.log"
    CustomLog "C:/xampp/apache/logs/philynda-ssl-access.log" common
</VirtualHost>
"@
Set-Content -Path $VhostConf -Value $vhost -Encoding ascii

Write-Host 'Opening Windows Firewall port 8443 for the local subnet...' -ForegroundColor Cyan
& netsh advfirewall firewall delete rule name='Philynda HTTPS 8443' *> $null
& netsh advfirewall firewall add rule name='Philynda HTTPS 8443' dir=in action=allow protocol=TCP localport=8443 remoteip=localsubnet profile=private,domain | Out-Host

Write-Host 'Testing Apache configuration...' -ForegroundColor Cyan
# Merge STDERR into STDOUT here so Windows PowerShell 5.1 cannot turn a normal
# Apache diagnostic line into a terminating NativeCommandError.
$apacheTestOutput = (& $Httpd -t 2>&1 | Out-String)
$apacheExitCode = $LASTEXITCODE
Set-Content -Path (Join-Path $SslDir 'apache-config-test.log') -Value $apacheTestOutput -Encoding utf8
if ($apacheExitCode -ne 0) {
    Write-Host 'Apache configuration test failed. Restoring the original httpd.conf backup.' -ForegroundColor Red
    Copy-Item $Backup $HttpdConf -Force
    throw "Apache config test failed (exit code $apacheExitCode). The original httpd.conf was restored. See $SslDir\apache-config-test.log for the Apache diagnostic output."
}

Write-Host ''
Write-Host 'SUCCESS: HTTPS setup completed.' -ForegroundColor Green
Write-Host "Secure mobile scanner URL:" -ForegroundColor Cyan
Write-Host "  https://$LanIp:8443/philynda/mobile_scanner.php" -ForegroundColor White
Write-Host ''
Write-Host 'Root CA certificate for phone installation:' -ForegroundColor Cyan
Write-Host "  $CaCrt" -ForegroundColor White
Write-Host ''
Write-Host 'Root CA private key (KEEP SECRET):' -ForegroundColor Yellow
Write-Host "  $CaKey" -ForegroundColor Yellow
Write-Host ''
Write-Host 'OpenSSL diagnostic log (if needed):' -ForegroundColor DarkGray
Write-Host "  $OpenSSLLog" -ForegroundColor DarkGray
Write-Host ''

if ($CaCreatedNow) {
    Write-Host 'A NEW Root CA was created on this PC.' -ForegroundColor Yellow
    Write-Host 'Run export_philynda_ca.bat and keep the backup in a secure location.' -ForegroundColor Yellow
} elseif ((Test-Path $PortableCaKey) -and (Test-Path $PortableCaCrt)) {
    Write-Host 'The existing Root CA was restored from the portable backup.' -ForegroundColor Green
    Write-Host 'Phones that trust this Root CA do not need the CA installed again.' -ForegroundColor Green
} else {
    Write-Host 'The existing Root CA on this PC was reused.' -ForegroundColor Green
}

Write-Host ''
Write-Host 'Restart Apache from the XAMPP Control Panel after this script finishes.' -ForegroundColor Yellow
Write-Host 'Offline mode: the PC and phone only need to share the same local network; Internet is not required.' -ForegroundColor Yellow
Write-Host 'Normal HTTP port 80 remains available.' -ForegroundColor Yellow
