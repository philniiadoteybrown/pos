<?php
$pagetitle="Dashboard";
include "assets/scripts/auth.php";
include "assets/scripts/dbconn.php";

/* =========================================================
   DASHBOARD FILTERS
   ========================================================= */
$filter    = $_GET['filter'] ?? 'today';
$monthyear = $_GET['monthyear'] ?? '';

/* Ghana local date. This keeps the dashboard's "today" date
   consistent with the application's expected timezone. */
date_default_timezone_set('Africa/Accra');
$todayDate = date('Y-m-d');

/* Safe query helpers. A failed dashboard query should return 0
   rather than breaking the entire dashboard page. */
function dashboardScalar($conn, $sql, $default = 0){
    $result = mysqli_query($conn, $sql);
    if(!$result){
        return $default;
    }

    $row = mysqli_fetch_assoc($result);
    if(!$row){
        return $default;
    }

    $value = array_values($row)[0] ?? $default;
    return is_numeric($value) ? (float)$value : $default;
}

function dashboardRows($conn, $sql){
    $result = mysqli_query($conn, $sql);
    return $result ?: false;
}

function percentChange($current, $previous){
    $current  = (float)$current;
    $previous = (float)$previous;

    if($previous == 0){
        return $current == 0 ? 0 : 100;
    }

    return round((($current - $previous) / $previous) * 100, 2);
}

/* =========================================================
   DATE CONDITIONS
   ========================================================= */
$startDate = $todayDate;
$endDate   = $todayDate;
$label     = "Today's";

if($monthyear !== '' && preg_match('/^\d{4}-\d{2}$/', $monthyear)){
    $parts = explode('-', $monthyear);
    $year  = (int)$parts[0];
    $month = (int)$parts[1];

    if($month >= 1 && $month <= 12){
        $startDate = sprintf('%04d-%02d-01', $year, $month);
        $endDate   = date('Y-m-t', strtotime($startDate));
        $label     = date('F Y', strtotime($startDate));
    }
}
elseif($filter === 'week'){
    $startDate = date('Y-m-d', strtotime('-6 days', strtotime($todayDate)));
    $endDate   = $todayDate;
    $label     = 'Weekly';
}
elseif($filter === 'month'){
    $startDate = date('Y-m-01', strtotime($todayDate));
    $endDate   = $todayDate;
    $label     = 'Monthly';
}

/* Use inclusive start/end timestamps instead of DATE(created_at).
   This is faster when created_at is indexed and avoids time-of-day
   edge cases. */
$startDateTime = $startDate . ' 00:00:00';
$endDateExclusive = date('Y-m-d 00:00:00', strtotime($endDate . ' +1 day'));

$previousStartDate = date('Y-m-d', strtotime($startDate . ' -1 day'));
$previousEndDate   = date('Y-m-d', strtotime($endDate . ' -1 day'));
$previousStartDateTime = $previousStartDate . ' 00:00:00';
$previousEndDateExclusive = date('Y-m-d 00:00:00', strtotime($previousEndDate . ' +1 day'));

$startEsc = mysqli_real_escape_string($conn, $startDateTime);
$endEsc   = mysqli_real_escape_string($conn, $endDateExclusive);
$prevStartEsc = mysqli_real_escape_string($conn, $previousStartDateTime);
$prevEndEsc   = mysqli_real_escape_string($conn, $previousEndDateExclusive);

$dateCondition = "created_at >= '$startEsc' AND created_at < '$endEsc'";
$previousDateCondition = "created_at >= '$prevStartEsc' AND created_at < '$prevEndEsc'";

/* =========================================================
   SALES
   ========================================================= */
$salesToday = dashboardScalar($conn, "
    SELECT COALESCE(SUM(total), 0) AS total
    FROM sales
    WHERE $dateCondition
");

$salesYesterday = dashboardScalar($conn, "
    SELECT COALESCE(SUM(total), 0) AS total
    FROM sales
    WHERE $previousDateCondition
");

/* =========================================================
   PURCHASES
   ========================================================= */
$purchaseToday = dashboardScalar($conn, "
    SELECT COALESCE(SUM(qty * unitprice), 0) AS total
    FROM purchase_items
    WHERE $dateCondition
");

$purchaseYesterday = dashboardScalar($conn, "
    SELECT COALESCE(SUM(qty * unitprice), 0) AS total
    FROM purchase_items
    WHERE $previousDateCondition
");

/* =========================================================
   CREDIT SALES
   ========================================================= */
$creditToday = (int)dashboardScalar($conn, "
    SELECT COUNT(DISTINCT customer_id) AS total
    FROM sales
    WHERE payment_method = 'credit'
    AND $dateCondition
");

/* =========================================================
   MONTH SALES
   ========================================================= */
$monthSales = dashboardScalar($conn, "
    SELECT COALESCE(SUM(total), 0) AS total
    FROM sales
    WHERE YEAR(created_at) = YEAR('$todayDate')
    AND MONTH(created_at) = MONTH('$todayDate')
");

if($monthyear !== '' && isset($year, $month)){
    $monthSales = dashboardScalar($conn, "
        SELECT COALESCE(SUM(total), 0) AS total
        FROM sales
        WHERE YEAR(created_at) = '$year'
        AND MONTH(created_at) = '$month'
    ");
}

$lastMonthSales = dashboardScalar($conn, "
    SELECT COALESCE(SUM(total), 0) AS total
    FROM sales
    WHERE YEAR(created_at) = YEAR(DATE_SUB('$todayDate', INTERVAL 1 MONTH))
    AND MONTH(created_at) = MONTH(DATE_SUB('$todayDate', INTERVAL 1 MONTH))
");

/* =========================================================
   PERCENTAGES
   ========================================================= */
$salesPercent    = percentChange($salesToday, $salesYesterday);
$purchasePercent = percentChange($purchaseToday, $purchaseYesterday);
$monthPercent    = percentChange($monthSales, $lastMonthSales);

/* =========================================================
   ACTUAL PROFIT

   IMPORTANT CORRECTION:
   Profit is calculated from each recorded sale item, using:

       actual sale subtotal
       MINUS cost of the actual quantity sold in pieces.

   sales_items.qty is the quantity entered at the POS and
   sales_items.unit_qty is the piece conversion for the selected
   sale unit (e.g. 1 box = 12 pieces).

   This avoids calculating today's profit from today's purchases,
   which is not the same thing as gross profit on today's sales.
   It also avoids relying on the product's current selling price
   after the sale has already been recorded.
   ========================================================= */
$profitToday = dashboardScalar($conn, "
    SELECT COALESCE(
        SUM(
            COALESCE(si.subtotal, 0)
            - (
                COALESCE(si.qty, 0)
                * COALESCE(NULLIF(si.unit_qty, 0), 1)
                * COALESCE(p.costperunit, 0)
            )
        ),
        0
    ) AS total
    FROM sales_items si
    INNER JOIN products p
        ON si.product_id = p.productid
    INNER JOIN sales s
        ON si.sale_id = s.id
    WHERE s.created_at >= '$startEsc'
    AND s.created_at < '$endEsc'
");

$profitYesterday = dashboardScalar($conn, "
    SELECT COALESCE(
        SUM(
            COALESCE(si.subtotal, 0)
            - (
                COALESCE(si.qty, 0)
                * COALESCE(NULLIF(si.unit_qty, 0), 1)
                * COALESCE(p.costperunit, 0)
            )
        ),
        0
    ) AS total
    FROM sales_items si
    INNER JOIN products p
        ON si.product_id = p.productid
    INNER JOIN sales s
        ON si.sale_id = s.id
    WHERE s.created_at >= '$prevStartEsc'
    AND s.created_at < '$prevEndEsc'
");

$profitPercent = percentChange($profitToday, $profitYesterday);

/* Keep the name used by the dashboard card. */
$todayProfit = $profitToday;

/* =========================================================
   STOCK / EXPECTED PROFIT
   ========================================================= */
$totalStockValue = dashboardScalar($conn, "
    SELECT COALESCE(SUM(totalstock * costperunit), 0) AS total
    FROM products
");

$expectedProfit = dashboardScalar($conn, "
    SELECT COALESCE(SUM(totalstock * (sellingprice - costperunit)), 0) AS total
    FROM products
");

/* =========================================================
   OUT OF STOCK
   ========================================================= */
$outOfStock = dashboardRows($conn, "
    SELECT productid, pname, pdesc, category, totalstock, qtyalert, unit
    FROM products
    WHERE totalstock <= 0
    ORDER BY category ASC, pname ASC
");

$outOfStockCount = $outOfStock ? mysqli_num_rows($outOfStock) : 0;

/* =========================================================
   CHART 1
   SALES VS PROFIT TREND FOR A SELECTED MONTH
========================================================= */


/*
|--------------------------------------------------------------------------
| Available months for first chart
|--------------------------------------------------------------------------
*/

$availableMonths = [];

$res = mysqli_query(
    $conn,
    "
    SELECT
        DATE_FORMAT(created_at, '%Y-%m') AS month_value,
        DATE_FORMAT(created_at, '%M %Y') AS month_label
    FROM sales
    GROUP BY YEAR(created_at), MONTH(created_at)
    ORDER BY YEAR(created_at) DESC, MONTH(created_at) DESC
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $availableMonths[] = [
            'value' => $r['month_value'],
            'label' => $r['month_label']
        ];

    }
}


/*
|--------------------------------------------------------------------------
| Default chart month
|--------------------------------------------------------------------------
*/

$chartMonth = $_GET['chart_month'] ?? date('Y-m');

if (!preg_match('/^\d{4}-\d{2}$/', $chartMonth)) {
    $chartMonth = date('Y-m');
}


/*
|--------------------------------------------------------------------------
| Validate selected month
|--------------------------------------------------------------------------
*/

$chartMonthTimestamp = strtotime(
    $chartMonth . '-01'
);

if ($chartMonthTimestamp === false) {
    $chartMonth = date('Y-m');
    $chartMonthTimestamp = strtotime($chartMonth . '-01');
}

$chartMonthStart = date(
    'Y-m-01',
    $chartMonthTimestamp
);

$chartMonthEnd = date(
    'Y-m-t',
    $chartMonthTimestamp
);

$chartMonthLabel = date(
    'F Y',
    $chartMonthTimestamp
);

$chartMonthStartEsc = mysqli_real_escape_string(
    $conn,
    $chartMonthStart . ' 00:00:00'
);

$chartMonthEndExclusiveEsc = mysqli_real_escape_string(
    $conn,
    date(
        'Y-m-d 00:00:00',
        strtotime($chartMonthEnd . ' +1 day')
    )
);


/*
|--------------------------------------------------------------------------
| Build all days of selected month
|--------------------------------------------------------------------------
*/

$monthDays = [];

$daysInMonth = (int)date(
    't',
    $chartMonthTimestamp
);

for ($day = 1; $day <= $daysInMonth; $day++) {

    $dateValue = sprintf(
        '%s-%02d',
        $chartMonth,
        $day
    );

    $monthDays[$dateValue] = [
        'date'   => $dateValue,
        'label'  => date(
            'd M',
            strtotime($dateValue)
        ),
        'sales'  => 0,
        'profit' => 0
    ];
}


/*
|--------------------------------------------------------------------------
| Monthly Sales by Day
|--------------------------------------------------------------------------
*/

$res = mysqli_query(
    $conn,
    "
    SELECT
        DATE(created_at) AS sale_date,
        COALESCE(SUM(total), 0) AS sales
    FROM sales
    WHERE created_at >= '$chartMonthStartEsc'
    AND created_at < '$chartMonthEndExclusiveEsc'
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at)
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $dateValue = $r['sale_date'];

        if (isset($monthDays[$dateValue])) {

            $monthDays[$dateValue]['sales'] =
                (float)$r['sales'];

        }
    }
}


/*
|--------------------------------------------------------------------------
| Monthly Actual Profit by Day
|--------------------------------------------------------------------------
*/

$res = mysqli_query(
    $conn,
    "
    SELECT
        DATE(s.created_at) AS sale_date,

        COALESCE(
            SUM(
                COALESCE(si.subtotal, 0)
                -
                (
                    COALESCE(si.qty, 0)
                    *
                    COALESCE(NULLIF(si.unit_qty, 0), 1)
                    *
                    COALESCE(p.costperunit, 0)
                )
            ),
            0
        ) AS profit

    FROM sales_items si

    INNER JOIN products p
        ON si.product_id = p.productid

    INNER JOIN sales s
        ON si.sale_id = s.id

    WHERE s.created_at >= '$chartMonthStartEsc'
    AND s.created_at < '$chartMonthEndExclusiveEsc'

    GROUP BY DATE(s.created_at)

    ORDER BY DATE(s.created_at)
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $dateValue = $r['sale_date'];

        if (isset($monthDays[$dateValue])) {

            $monthDays[$dateValue]['profit'] =
                (float)$r['profit'];

        }
    }
}


$monthlyTrendData = array_values(
    $monthDays
);


/* =========================================================
   CHART 2
   SALES VS PURCHASES VS PROFIT FOR A SELECTED YEAR
========================================================= */


/*
|--------------------------------------------------------------------------
| Available years
|--------------------------------------------------------------------------
*/

$chartYears = [];

$res = mysqli_query(
    $conn,
    "
    SELECT year_value
    FROM
    (
        SELECT YEAR(created_at) AS year_value
        FROM sales

        UNION

        SELECT YEAR(created_at) AS year_value
        FROM purchase_items
    ) years

    WHERE year_value IS NOT NULL

    ORDER BY year_value DESC
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $chartYears[] =
            (int)$r['year_value'];

    }
}


/*
|--------------------------------------------------------------------------
| Always include current year
|--------------------------------------------------------------------------
*/

$currentYear = (int)date('Y');

if (!in_array($currentYear, $chartYears)) {

    $chartYears[] =
        $currentYear;

}

rsort($chartYears);


/*
|--------------------------------------------------------------------------
| Selected chart year
|--------------------------------------------------------------------------
*/

$chartYear = isset($_GET['chart_year'])
    ? intval($_GET['chart_year'])
    : $currentYear;


if (!in_array($chartYear, $chartYears)) {

    $chartYear =
        $currentYear;

}


/*
|--------------------------------------------------------------------------
| Create January - December
|--------------------------------------------------------------------------
*/

$yearChartData = [];

$monthNames = [
    1  => 'Jan',
    2  => 'Feb',
    3  => 'Mar',
    4  => 'Apr',
    5  => 'May',
    6  => 'Jun',
    7  => 'Jul',
    8  => 'Aug',
    9  => 'Sep',
    10 => 'Oct',
    11 => 'Nov',
    12 => 'Dec'
];


for ($month = 1; $month <= 12; $month++) {

    $yearChartData[$month] = [
        'month_number' => $month,
        'month'         => $monthNames[$month],
        'sales'         => 0,
        'purchases'     => 0,
        'profit'        => 0
    ];

}


/*
|--------------------------------------------------------------------------
| YEARLY SALES
|--------------------------------------------------------------------------
*/

$res = mysqli_query(
    $conn,
    "
    SELECT
        MONTH(created_at) AS month_number,
        COALESCE(SUM(total), 0) AS sales

    FROM sales

    WHERE YEAR(created_at) = '$chartYear'

    GROUP BY MONTH(created_at)

    ORDER BY MONTH(created_at)
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $monthNumber =
            (int)$r['month_number'];

        if (isset($yearChartData[$monthNumber])) {

            $yearChartData[$monthNumber]['sales'] =
                (float)$r['sales'];

        }
    }
}


/*
|--------------------------------------------------------------------------
| YEARLY PURCHASES
|--------------------------------------------------------------------------
*/

$res = mysqli_query(
    $conn,
    "
    SELECT
        MONTH(created_at) AS month_number,

        COALESCE(
            SUM(
                COALESCE(qty, 0)
                *
                COALESCE(unitprice, 0)
            ),
            0
        ) AS purchases

    FROM purchase_items

    WHERE YEAR(created_at) = '$chartYear'

    GROUP BY MONTH(created_at)

    ORDER BY MONTH(created_at)
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $monthNumber =
            (int)$r['month_number'];

        if (isset($yearChartData[$monthNumber])) {

            $yearChartData[$monthNumber]['purchases'] =
                (float)$r['purchases'];

        }
    }
}


/*
|--------------------------------------------------------------------------
| YEARLY ACTUAL PROFIT
|--------------------------------------------------------------------------
*/

$res = mysqli_query(
    $conn,
    "
    SELECT

        MONTH(s.created_at) AS month_number,

        COALESCE(
            SUM(
                COALESCE(si.subtotal, 0)
                -
                (
                    COALESCE(si.qty, 0)
                    *
                    COALESCE(NULLIF(si.unit_qty, 0), 1)
                    *
                    COALESCE(p.costperunit, 0)
                )
            ),
            0
        ) AS profit

    FROM sales_items si

    INNER JOIN products p
        ON si.product_id = p.productid

    INNER JOIN sales s
        ON si.sale_id = s.id

    WHERE YEAR(s.created_at) = '$chartYear'

    GROUP BY MONTH(s.created_at)

    ORDER BY MONTH(s.created_at)
    "
);

if ($res) {

    while ($r = mysqli_fetch_assoc($res)) {

        $monthNumber =
            (int)$r['month_number'];

        if (isset($yearChartData[$monthNumber])) {

            $yearChartData[$monthNumber]['profit'] =
                (float)$r['profit'];

        }
    }
}


$yearChartData =
    array_values($yearChartData);
?>
<?php
/* =========================================================
   DASHBOARD SCANNER IP
   Prefer Apache's bound LAN IPv4. If Apache reports localhost,
   fall back to the PC hostname's IPv4 addresses.
========================================================= */
$dashboardScannerIp = $_SERVER['SERVER_ADDR'] ?? '';

function dashboardIsPrivateIpv4($ip){
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;
    $parts = array_map('intval', explode('.', $ip));
    if (count($parts) !== 4) return false;
    return (
        $parts[0] === 10 ||
        ($parts[0] === 172 && $parts[1] >= 16 && $parts[1] <= 31) ||
        ($parts[0] === 192 && $parts[1] === 168)
    );
}

if (!dashboardIsPrivateIpv4($dashboardScannerIp)) {
    $dashboardScannerIp = '';
}

if ($dashboardScannerIp === '') {
    $hostName = gethostname();
    if ($hostName) {
        $hostIps = @gethostbynamel($hostName);
        if (is_array($hostIps)) {
            foreach ($hostIps as $candidateIp) {
                if (dashboardIsPrivateIpv4($candidateIp)) {
                    $dashboardScannerIp = $candidateIp;
                    break;
                }
            }
        }
    }
}

if ($dashboardScannerIp === '' && PHP_OS_FAMILY === 'Windows' && function_exists('exec')) {
    $lines = [];
    @exec('ipconfig', $lines);
    foreach ($lines as $line) {
        if (preg_match('/(?:IPv4[^:]*|IP Address[^:]*):\s*([0-9.]+)/i', $line, $m) && dashboardIsPrivateIpv4($m[1])) {
            $dashboardScannerIp = $m[1];
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<!-- Mirrored from mannatthemes.com/annex/vertical/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 11:12:56 GMT -->

<head>
    <?php include "assets/sections/headers/header_tag.php" ?>

    <style>
        /* Main dashboard: fixed 70% / 30% two-column layout */
        .dashboard-layout {
            display: grid;
            grid-template-columns: minmax(0, 7.5fr) minmax(280px, 2.5fr);
            gap: 20px;
            align-items: stretch;
            width: 100%;
        }

        .dashboard-left,
        .dashboard-right {
            min-width: 0;
            min-height: 0;
            box-sizing: border-box;
        }

        .dashboard-right {
            height: 1300px;
            min-height: 0;
            overflow: hidden;
        }

        .dashboard-right > .card {
            height: 100%;
            min-height: 0;
            margin-bottom: 0;
            overflow: hidden;
        }

        /* Chart layout */
        .full-width-chart {
            width: 100%;
        }

        .chart-container {
            position: relative;
            width: 100%;
            height: 430px;
        }

        @media (max-width: 767px) {
            .chart-container {
                height: 330px;
            }
        }


        @media (max-width: 991.98px) {
            .dashboard-layout {
                grid-template-columns: 1fr;
            }

            .dashboard-right {
                position: static;
            }
        }
    

        /* =====================================================
           DASHBOARD TOP MENU
           Replaces the left sidebar on this dashboard only.
        ===================================================== */
        .dashboard-top-nav-wrap {
            width: 100%;
            margin: 0 0 18px;
        }

        .dashboard-top-nav {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            align-items: stretch;
            gap: 14px;
            width: 100%;
            padding: 14px;
            background: #fff;
            border: 1px solid #e2e6ea;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,.05);
        }

        .dashboard-menu-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            min-height: 128px;
            padding: 24px 22px;
            border-radius: 10px;
            text-decoration: none !important;
            white-space: nowrap;
            font-size: 22px;
            font-weight: 700;
            transition: transform .15s ease, box-shadow .15s ease;
        }

        .dashboard-menu-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 3px 9px rgba(0,0,0,.12);
        }

        .dashboard-menu-btn .fa,
        .dashboard-menu-btn .mdi {
            font-size: 38px;
        }

        .dashboard-scanner-bar {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 12px;
            width: 100%;
            flex-wrap: wrap;
        }

        .dashboard-scanner-status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            flex: 1 1 auto;
            min-height: 64px;
            padding: 10px 14px;
            border: 1px solid #dfe5ea;
            border-radius: 10px;
            background: #f8f9fa;
            font-size: 15px;
            box-shadow: 0 2px 6px rgba(0,0,0,.04);
        }

        .dashboard-scanner-status.show {
            display: flex;
        }

        .dashboard-scanner-status strong {
            color: #856404;
        }

        .dashboard-scanner-status.connected {
            background: #eaf7ef;
            border-color: #badbcc;
        }

        .dashboard-scanner-status.connected strong {
            color: #198754;
        }

        .dashboard-scanner-status-left,
        .dashboard-scanner-status-right {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
        }

        .dashboard-scanner-status-left {
            min-width: 0;
        }

        .dashboard-scanner-status-right {
            margin-left: auto;
            justify-content: flex-end;
        }

        .dashboard-scanner-ip {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            font-weight: 600;
        }

        .dashboard-scanner-ip-value {
            min-width: 112px;
            font-family: Consolas, 'Courier New', monospace;
            letter-spacing: .3px;
        }

        .dashboard-scanner-ip-toggle,
        .dashboard-scanner-disconnect {
            min-height: 48px;
            padding: 9px 15px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 700;
        }

        .dashboard-scanner-ip-toggle {
            border: 1px solid #cfd6dc;
            background: #fff;
        }

        .dashboard-scanner-ip-toggle:hover {
            background: #f1f3f5;
        }

        .dashboard-scanner-disconnect {
            border: 0;
        }

        .dashboard-content-inner {
            width: 100%;
        }

        /* This dashboard does not use the fixed-left sidebar. */
        body.dashboard-no-sidebar,
        body.dashboard-no-sidebar #wrapper,
        body.dashboard-no-sidebar .content-page,
        body.dashboard-no-sidebar .content,
        body.dashboard-no-sidebar .page-content-wrapper,
        body.dashboard-no-sidebar .container-fluid {
            width: 100% !important;
            max-width: 100% !important;
        }

        body.dashboard-no-sidebar .content-page {
            margin-left: 0 !important;
        }

        @media (max-width: 991.98px) {
            .dashboard-top-nav {
                grid-template-columns: repeat(3, minmax(0, 1fr));
                padding: 12px;
                gap: 10px;
            }

            .dashboard-menu-btn {
                min-width: 0;
                min-height: 116px;
                font-size: 19px;
                padding: 18px 12px;
            }

            .dashboard-menu-btn .fa,
            .dashboard-menu-btn .mdi {
                font-size: 34px;
            }

            .dashboard-scanner-bar {
                justify-content: stretch;
                align-items: stretch;
                gap: 8px;
            }

            .dashboard-scanner-status {
                flex: 1 1 100%;
                min-height: 58px;
            }

            .dashboard-scanner-status-right {
                width: 100%;
                margin-left: 0;
                justify-content: flex-start;
            }

            .dashboard-scanner-ip-toggle,
            .dashboard-scanner-disconnect {
                min-height: 52px;
            }
        }

        @media (max-width: 767.98px) {
            .dashboard-top-nav-wrap {
                margin-bottom: 12px;
            }

            .dashboard-top-nav {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
                padding: 10px;
            }

            .dashboard-menu-btn {
                width: 100%;
                min-width: 0;
                min-height: 122px;
                font-size: 19px;
                padding: 18px 8px;
                flex-direction: column;
            }

            .dashboard-menu-btn .fa,
            .dashboard-menu-btn .mdi {
                font-size: 35px;
            }

            .dashboard-menu-btn span.menu-label {
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .dashboard-scanner-status.show {
                display: flex;
                flex-direction: column;
                align-items: stretch;
                gap: 10px;
                padding: 12px;
            }

            .dashboard-scanner-status-left,
            .dashboard-scanner-status-right {
                width: 100%;
            }

            .dashboard-scanner-status-right {
                justify-content: flex-start;
            }

            .dashboard-scanner-ip-value {
                min-width: 100px;
            }

            .page-title-box {
                padding: 8px 0;
            }

            .page-title-box .page-title {
                font-size: 20px;
            }

            .dashboard-layout {
                gap: 12px;
            }
        }

        @media (max-width: 420px) {
            .dashboard-top-nav {
                grid-template-columns: 1fr 1fr;
                gap: 8px;
                padding: 8px;
            }

            .dashboard-menu-btn {
                min-height: 96px;
                font-size: 16px;
                padding: 14px 6px;
            }

            .dashboard-menu-btn .fa,
            .dashboard-menu-btn .mdi {
                font-size: 27px;
            }
        }

    </style>
</head>

<body class="fixed-left dashboard-no-sidebar">
    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div><!-- Begin page -->
    <div id="wrapper">
        <!-- Start right Content here -->
        <div class="content-page">
            <!-- Start content -->
            <div class="content">
                <!-- Top Bar Start -->
                <?php include "assets/sections/topbar.php" ?>
                <!-- Top Bar End -->


                <!-- =====================================================
                     DASHBOARD TOP MENU
                     The dashboard uses quick-access icon buttons instead
                     of the left sidebar.
                     ===================================================== -->
                <div class="dashboard-top-nav-wrap">

                    <div class="dashboard-top-nav" role="navigation" aria-label="Dashboard menu">

                        <a href="index.php" class="dashboard-menu-btn btn btn-primary" title="Dashboard">
                            <span class="fa fa-dashboard"></span>
                            <span class="menu-label">Dashboard</span>
                        </a>

                        <a href="pos.php" class="dashboard-menu-btn btn btn-success" title="POS">
                            <span class="fa fa-shopping-cart"></span>
                            <span class="menu-label">POS</span>
                        </a>

                        <a href="products.php" class="dashboard-menu-btn btn btn-info" title="Products">
                            <span class="fa fa-cubes"></span>
                            <span class="menu-label">Products</span>
                        </a>

                        <a href="sales_items.php" class="dashboard-menu-btn btn btn-warning" title="Sales">
                            <span class="fa fa-list-alt"></span>
                            <span class="menu-label">Sales</span>
                        </a>

                        <a href="customers.php" class="dashboard-menu-btn btn btn-dark" title="People">
                            <span class="fa fa-users"></span>
                            <span class="menu-label">People</span>
                        </a>


                    </div>

                    <div class="dashboard-scanner-bar">
                        <div id="dashboardScannerStatus"
                            class="dashboard-scanner-status show"
                            role="status"
                            aria-live="polite">

                            <div class="dashboard-scanner-status-left">
                                <span>Scanner Status: <strong id="dashboardScannerStatusText">Checking...</strong></span>

                                <span class="dashboard-scanner-ip">
                                    <span>IP:</span>
                                    <span id="dashboardScannerIpValue" class="dashboard-scanner-ip-value"></span>
                                </span>
                            </div>

                            <div class="dashboard-scanner-status-right">
                                <button type="button"
                                    id="dashboardScannerIpToggle"
                                    class="btn dashboard-scanner-ip-toggle"
                                    onclick="toggleDashboardScannerIp()">
                                    <span class="fa fa-eye-slash"></span> Hide IP
                                </button>

                                <button type="button"
                                    id="dashboardScannerDisconnect"
                                    class="btn btn-danger dashboard-scanner-disconnect"
                                    onclick="dashboardStopMobileScanner()">
                                    <span class="fa fa-power-off"></span> Disconnect
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="page-content-wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <!-- <div class="btn-group float-right">
                                        <ol class="breadcrumb hide-phone p-0 m-0">
                                            <li class="breadcrumb-item"><a href="#">Annex</a></li>
                                            <li class="breadcrumb-item active">Dashboard</li>
                                        </ol>
                                    </div> -->
                                    <h4 class="page-title">Dashboard</h4>
                                </div>
                            </div>
                        </div><!-- end page title end breadcrumb -->
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-xl-12">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">

                                            <button class="btn btn-sm <?= $filter=='today'?'btn-primary':'btn-light' ?>"
                                                onclick="setFilter('today')">
                                                Today
                                            </button>

                                            <button class="btn btn-sm <?= $filter=='week'?'btn-info':'btn-light' ?>"
                                                onclick="setFilter('week')">
                                                Week
                                            </button>

                                            <button class="btn btn-sm <?= $filter=='month'?'btn-success':'btn-light' ?>"
                                                onclick="setFilter('month')">
                                                Month
                                            </button>

                                            <select id="monthYearFilter" class="form-control" style="width:200px;"
                                                onchange="filterMonthYear(this.value)">
                                                <option value="">Select Month</option>

                                                <?php for($i=0; $i<12; $i++){
            $time = strtotime("-$i month");
            $value = date("Y-m", $time);
            $text  = date("F Y", $time);
        ?>
                                                <option value="<?= $value ?>"
                                                    <?= (($_GET['monthyear'] ?? '') == $value) ? 'selected' : '' ?>>
                                                    <?= $text ?>
                                                </option>
                                                <?php } ?>
                                            </select>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="dashboard-layout">
                            <div class="dashboard-left">
                                <div class="dashboard-main">
                        <div class="row">

                            <!-- SALES TODAY -->
                            <div class="col-md-6 col-lg-6 col-xl-4">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="d-flex flex-row">

                                            <div class="col-3 align-self-center">
                                                <div class="round"><i class="mdi mdi-cash"></i></div>
                                            </div>

                                            <div class="col-6 text-center align-self-center">
                                                <h5 class="mt-0 round-inner">GHS <?= number_format($salesToday,2) ?>
                                                </h5>
                                                <p class="mb-0 text-muted"><?= $label ?> Sales</p>
                                            </div>

                                            <div class="col-3 align-self-center">
                                                <h6
                                                    class="m-0 text-center <?= ($salesPercent>=0)?'text-success':'text-danger' ?>">
                                                    <i
                                                        class="mdi <?= ($salesPercent>=0)?'mdi-arrow-up':'mdi-arrow-down' ?>"></i>
                                                    <?= $salesPercent ?>%
                                                </h6>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- TOTAL STOCK -->
                            <div class="col-md-6 col-lg-6 col-xl-4">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="d-flex flex-row">
                                            <div class="col-3 align-self-center">
                                                <div class="round"><i class="mdi mdi-package-variant"></i></div>
                                            </div>
                                            <div class="col-6 text-center align-self-center">
                                                <h5 class="mt-0 round-inner">
                                                    GHS <?= number_format($totalStockValue,2) ?>
                                                </h5>
                                                <p class="mb-0 text-muted">Total Stock</p>
                                            </div>
                                            <div class="col-3 align-self-center">
                                                <h6 class="m-0 text-center text-info">
                                                    <i class="mdi mdi-warehouse"></i>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- CREDIT CUSTOMERS -->
                            <div class="col-md-6 col-lg-6 col-xl-4">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="d-flex flex-row">

                                            <div class="col-3 align-self-center">
                                                <div class="round"><i class="mdi mdi-account-alert"></i></div>
                                            </div>

                                            <div class="col-6 text-center align-self-center">
                                                <h5 class="mt-0 round-inner"><?= $creditToday ?></h5>
                                                <p class="mb-0 text-muted">Credit Sales Today</p>
                                            </div>

                                            <div class="col-3 align-self-center">
                                                <h6 class="text-warning text-center">
                                                    <i class="mdi mdi-alert"></i> Active
                                                </h6>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">

                            <!-- TODAY'S PROFIT -->
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="d-flex flex-row">
                                            <div class="col-3 align-self-center">
                                                <div class="round"><i class="mdi mdi-cash-multiple"></i></div>
                                            </div>
                                            <div class="col-6 text-center align-self-center">
                                                <h5 class="<?= ($todayProfit >= 0)?'text-success':'text-danger' ?>">
                                                    GHS <?= number_format($todayProfit,2) ?>
                                                </h5>
                                                <p class="mb-0 text-muted"><?= htmlspecialchars($label) ?> Profit</p>
                                            </div>
                                            <div class="col-3 align-self-center">
                                                <h6 class="m-0 text-center <?= ($todayProfit>=0)?'text-success':'text-danger' ?>">
                                                    <i class="mdi <?= ($todayProfit>=0)?'mdi-arrow-up':'mdi-arrow-down' ?>"></i>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- EXPECTED PROFIT -->
                            <div class="col-md-6 col-lg-6 col-xl-6">
                                <div class="card m-b-30">
                                    <div class="card-body">
                                        <div class="d-flex flex-row">
                                            <div class="col-3 align-self-center">
                                                <div class="round"><i class="mdi mdi-chart-line"></i></div>
                                            </div>
                                            <div class="col-6 text-center align-self-center">
                                                <h5 class="<?= ($expectedProfit >= 0)?'text-success':'text-danger' ?>">
                                                    GHS <?= number_format($expectedProfit,2) ?>
                                                </h5>
                                                <p class="mb-0 text-muted">Expected Profit</p>
                                            </div>
                                            <div class="col-3 align-self-center">
                                                <h6 class="m-0 text-center <?= ($expectedProfit>=0)?'text-success':'text-danger' ?>">
                                                    <i class="mdi mdi-trending-up"></i>
                                                </h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Column -->
                    </div>

                                <!-- =================================================
                                     CHART 1
                                     SALES VS PROFIT FOR SELECTED MONTH
                                ================================================= -->

                                <div class="row">

                                    <div class="col-md-12">

                                        <div
                                            class="card m-b-30 full-width-chart"
                                        >

                                            <div class="card-body">


                                                <div
                                                    class="
                                                    d-flex
                                                    justify-content-between
                                                    align-items-center
                                                    flex-wrap
                                                    mb-3
                                                    "
                                                >


                                                    <div>

                                                        <h5
                                                            class="header-title mt-0 mb-1"
                                                        >

                                                            Sales vs Profit Trend

                                                        </h5>

                                                        <p
                                                            class="text-muted mb-0"
                                                        >

                                                            Daily sales and actual
                                                            profit for
                                                            <?= htmlspecialchars(
                                                                $chartMonthLabel
                                                            ) ?>

                                                        </p>

                                                    </div>


                                                    <!-- MONTH FILTER -->

                                                    <div>

                                                        <select
                                                            id="chartMonth"
                                                            class="form-control"
                                                            style="min-width:190px;"
                                                            onchange="filterChartMonth(this.value)"
                                                        >

                                                            <?php

                                                            /*
                                                             * Show existing
                                                             * transaction months.
                                                             */

                                                            foreach (
                                                                $availableMonths
                                                                as $availableMonth
                                                            ) {

                                                            ?>

                                                                <option
                                                                    value="<?= htmlspecialchars(
                                                                        $availableMonth['value']
                                                                    ) ?>"
                                                                    <?= $availableMonth['value'] == $chartMonth
                                                                        ? 'selected'
                                                                        : '' ?>
                                                                >

                                                                    <?= htmlspecialchars(
                                                                        $availableMonth['label']
                                                                    ) ?>

                                                                </option>

                                                            <?php } ?>


                                                            <?php

                                                            /*
                                                             * If there are no
                                                             * sales yet for the
                                                             * current month,
                                                             * still show it.
                                                             */

                                                            if (
                                                                empty($availableMonths)
                                                            ) {

                                                            ?>

                                                                <option
                                                                    value="<?= date('Y-m') ?>"
                                                                    selected
                                                                >

                                                                    <?= date('F Y') ?>

                                                                </option>

                                                            <?php } ?>


                                                        </select>

                                                    </div>


                                                </div>


                                                <div class="chart-container">

                                                    <canvas
                                                        id="monthlyTrendChart"
                                                    ></canvas>

                                                </div>


                                            </div>

                                        </div>

                                    </div>

                                </div>


                                <!-- =================================================
                                     CHART 2
                                     YEARLY SALES VS PURCHASES VS PROFIT
                                ================================================= -->

                                <div class="row">

                                    <div class="col-md-12">

                                        <div
                                            class="card m-b-30 full-width-chart"
                                        >

                                            <div class="card-body">


                                                <div
                                                    class="
                                                    d-flex
                                                    justify-content-between
                                                    align-items-center
                                                    flex-wrap
                                                    mb-3
                                                    "
                                                >


                                                    <div>

                                                        <h5
                                                            class="header-title mt-0 mb-1"
                                                        >

                                                            Sales vs Purchases vs Profit

                                                        </h5>

                                                        <p
                                                            class="text-muted mb-0"
                                                        >

                                                            Monthly comparison for
                                                            <?= $chartYear ?>

                                                        </p>

                                                    </div>


                                                    <!-- YEAR FILTER -->

                                                    <div>

                                                        <select
                                                            id="chartYear"
                                                            class="form-control"
                                                            style="min-width:150px;"
                                                            onchange="filterChartYear(this.value)"
                                                        >

                                                            <?php

                                                            foreach (
                                                                $chartYears
                                                                as $yearOption
                                                            ) {

                                                            ?>

                                                                <option
                                                                    value="<?= $yearOption ?>"
                                                                    <?= $yearOption == $chartYear
                                                                        ? 'selected'
                                                                        : '' ?>
                                                                >

                                                                    <?= $yearOption ?>

                                                                </option>

                                                            <?php } ?>

                                                        </select>

                                                    </div>


                                                </div>


                                                <div class="chart-container">

                                                    <canvas
                                                        id="yearlyComparisonChart"
                                                    ></canvas>

                                                </div>


                                            </div>

                                        </div>

                                    </div>

                                </div>


                                <hr>

                    <div class="row">
                        <div class="col-md-12 col-lg-12 col-xl-4">
                            <div class="card bg-white m-b-30">
                                <div class="card-body">
                                    <h5 class="header-title mb-4 mt-0">Customers with Outstanding Balance
                                    </h5>
                                    <?php
                                        $debtors = mysqli_query($conn,"
                                        SELECT name, phone, balance, last_payment_date
                                        FROM customers
                                        WHERE balance > 0
                                        ORDER BY balance DESC
                                        ");
                                        ?>
                                    <div class="table-responsive">
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Phone</th>
                                                    <th>Balance (GH¢)</th>
                                                    <th>Last Payment</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php if(mysqli_num_rows($debtors) > 0){ ?>
                                                <?php while($c = mysqli_fetch_assoc($debtors)){ ?>
                                                <tr>
                                                    <td><?php echo $c['name']; ?></td>
                                                    <td><?php echo $c['phone']; ?></td>
                                                    <td style="color:red;font-weight:bold;">
                                                        <?php echo number_format($c['balance'],2); ?>
                                                    </td>
                                                    <td><?php echo $c['last_payment_date'] ?? 'N/A'; ?></td>
                                                </tr>
                                                <?php } ?>
                                                <?php } else { ?>
                                                <tr>
                                                    <td colspan="4">No customers with outstanding balance
                                                    </td>
                                                </tr>
                                                <?php } ?>

                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="col-md-12 col-lg-12 col-xl-4">
                            <div class="card bg-white m-b-30">
                                <div class="card-body">
                                    <?php
                                        $topItems = mysqli_query($conn,"
                                        SELECT product_names, COUNT(*) as total_sales
                                        FROM sales
                                        GROUP BY product_names
                                        ORDER BY total_sales DESC
                                        LIMIT 5
                                        ");
                                        ?>
                                    <h5 class="header-title mt-0 mb-4">Most Sold Items</h5>

                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Product</th>
                                                    <th>Sales Count</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php while($item = mysqli_fetch_assoc($topItems)){ ?>
                                                <tr>
                                                    <td><?php echo $item['product_names']; ?></td>
                                                    <td><?php echo $item['total_sales']; ?></td>
                                                </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-12 col-xl-4">
                            <div class="card bg-white m-b-30">
                                <div class="card-body">
                                    <?php
$topProfit = mysqli_query($conn,"
SELECT 
    product_names as pname,
    SUM(total) as sales
FROM sales
GROUP BY product_names
ORDER BY sales DESC
LIMIT 5
");
?>
                                    <h5 class="header-title mt-0 mb-4">Top Profit Products</h5>

                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Revenue</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <?php while($p = mysqli_fetch_assoc($topProfit)){ ?>
                                            <tr>
                                                <td><?= $p['pname'] ?></td>
                                                <td><?= number_format($p['sales'],2) ?></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>




                            <div class="dashboard-right">
                                <div class="card bg-white m-b-30" style="height:100%;">
                                    <div class="card-body" style="height:100%;display:flex;flex-direction:column;">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h5 class="header-title mt-0 mb-0">
                                                <i class="mdi mdi-package-variant-closed text-danger"></i>
                                                Out of Stock
                                            </h5>
                                            <span class="badge badge-danger"><?= $outOfStockCount ?></span>
                                        </div>

                                        <div style="flex:1;overflow-y:auto;min-height:0;">
                                            <?php if($outOfStockCount > 0){ ?>
                                                <?php while($stockItem = mysqli_fetch_assoc($outOfStock)){ ?>
                                                    <div style="border:1px solid #f1f1f1;border-left:4px solid #dc3545;border-radius:5px;padding:10px;margin-bottom:10px;background:#fff;">
                                                        <div style="font-weight:600;">
                                                            <?= htmlspecialchars($stockItem['pname']) ?>
                                                        </div>
                                                        <?php if(!empty($stockItem['pdesc'])){ ?>
                                                            <small class="text-muted">
                                                                <?= htmlspecialchars($stockItem['pdesc']) ?>
                                                            </small>
                                                        <?php } ?>
                                                        <div class="mt-1">
                                                            <span class="badge badge-danger">Out of Stock</span>
                                                            <?php if(!empty($stockItem['category'])){ ?>
                                                                <small class="text-muted ml-1">
                                                                    <?= htmlspecialchars($stockItem['category']) ?>
                                                                </small>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="mt-2">
                                                            <a href="restockproducts.php?id=<?= urlencode($stockItem['productid']) ?>"
                                                               class="btn btn-sm btn-dark">
                                                                <i class="fa fa-cart-arrow-down"></i> Restock
                                                            </a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            <?php } else { ?>
                                                <div class="text-center text-muted py-4">
                                                    <i class="mdi mdi-check-circle-outline" style="font-size:40px;"></i>
                                                    <p class="mb-0 mt-2">No products are out of stock.</p>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div><!-- container -->
        </div><!-- Page content Wrapper -->
    </div><!-- content -->
    <footer class="footer"><?php include "assets/sections/footers/footer.php"?></footer>
    </div><!-- End Right content here -->
    </div><!-- END wrapper -->
    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/modernizr.min.js"></script>
    <script src="assets/js/detect.js"></script>
    <script src="assets/js/fastclick.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/jquery.blockUI.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/jquery.nicescroll.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/plugins/skycons/skycons.min.js"></script>
    <script src="assets/plugins/raphael/raphael-min.js"></script>
    <script src="assets/plugins/morris/morris.min.js"></script>
    <script src="assets/pages/dashborad.js"></script><!-- App js -->
    <script src="assets/js/app.js"></script>
    <script>
    /* BEGIN SVG WEATHER ICON */
    if (typeof Skycons !== 'undefined') {
        var icons = new Skycons({
                "color": "#fff"
            }, {
                "resizeClear": true
            }),
            list = [
                "clear-day", "clear-night", "partly-cloudy-day",
                "partly-cloudy-night", "cloudy", "rain", "sleet", "snow", "wind",
                "fog"
            ],
            i;

        for (i = list.length; i--;)
            icons.set(list[i], list[i]);
        icons.play();
    };

    // scroll

    $(document).ready(function() {

        $("#boxscroll").niceScroll({
            cursorborder: "",
            cursorcolor: "#cecece",
            boxzoom: true
        });
        $("#boxscroll2").niceScroll({
            cursorborder: "",
            cursorcolor: "#cecece",
            boxzoom: true
        });

    });
    </script>

    <script src="assets/js/chart.js"></script>

    <script>
    function setFilter(type) {
        window.location.href = '?filter=' + type;
    }

    function filterMonthYear(value) {

        if (value == '') {
            window.location.href = '?filter=today';
            return;
        }

        window.location.href = '?monthyear=' + value;
    }

    /* =====================================================
       CHART MONTH FILTER
    ===================================================== */

    function filterChartMonth(value) {

        if (!value) {

            return;

        }

        var url =
            new URL(
                window.location.href
            );

        url.searchParams.set(
            'chart_month',
            value
        );

        window.location.href =
            url.toString();

    }


    /* =====================================================
       CHART YEAR FILTER
    ===================================================== */

    function filterChartYear(value) {

        if (!value) {

            return;

        }

        var url =
            new URL(
                window.location.href
            );

        url.searchParams.set(
            'chart_year',
            value
        );

        window.location.href =
            url.toString();

    }


    /* =====================================================
       CHART DATA
    ===================================================== */

    const monthlyTrendData =
        <?= json_encode(
            $monthlyTrendData,
            JSON_NUMERIC_CHECK
        ); ?>;


    const yearChartData =
        <?= json_encode(
            $yearChartData,
            JSON_NUMERIC_CHECK
        ); ?>;


    /* =====================================================
       CHART 1
       SALES VS PROFIT TREND FOR MONTH
    ===================================================== */

    const monthlyTrendCanvas =
        document.getElementById(
            'monthlyTrendChart'
        );


    if (monthlyTrendCanvas) {

        new Chart(
            monthlyTrendCanvas,
            {

                type: 'line',

                data: {

                    labels:
                        monthlyTrendData.map(
                            function(item) {

                                return item.label;

                            }
                        ),


                    datasets: [

                        {

                            label: 'Sales',

                            data:
                                monthlyTrendData.map(
                                    function(item) {

                                        return item.sales;

                                    }
                                ),

                            fill: false,

                            tension: 0.35,

                            borderWidth: 3,

                            pointRadius: 3,

                            pointHoverRadius: 6

                        },


                        {

                            label: 'Profit',

                            data:
                                monthlyTrendData.map(
                                    function(item) {

                                        return item.profit;

                                    }
                                ),

                            fill: false,

                            tension: 0.35,

                            borderWidth: 3,

                            pointRadius: 3,

                            pointHoverRadius: 6

                        }

                    ]

                },


                options: {

                    responsive: true,

                    maintainAspectRatio: false,


                    interaction: {

                        intersect: false,

                        mode: 'index'

                    },


                    plugins: {

                        legend: {

                            display: true,

                            position: 'top'

                        },


                        tooltip: {

                            callbacks: {

                                label:
                                    function(context) {

                                        return (
                                            context.dataset.label +
                                            ': GHS ' +
                                            Number(
                                                context.raw
                                            ).toLocaleString(
                                                undefined,
                                                {
                                                    minimumFractionDigits: 2,
                                                    maximumFractionDigits: 2
                                                }
                                            )
                                        );

                                    }

                            }

                        }

                    },


                    scales: {

                        x: {

                            title: {

                                display: true,

                                text: 'Day'

                            }

                        },


                        y: {

                            beginAtZero: true,

                            title: {

                                display: true,

                                text: 'Amount (GHS)'

                            },


                            ticks: {

                                callback:
                                    function(value) {

                                        return 'GHS ' +
                                            Number(
                                                value
                                            ).toLocaleString();

                                    }

                            }

                        }

                    }

                }

            }
        );

    }


    /* =====================================================
       CHART 2
       YEARLY SALES VS PURCHASES VS PROFIT
    ===================================================== */

    const yearlyComparisonCanvas =
        document.getElementById(
            'yearlyComparisonChart'
        );


    if (yearlyComparisonCanvas) {

        new Chart(
            yearlyComparisonCanvas,
            {

                type: 'bar',

                data: {

                    labels:
                        yearChartData.map(
                            function(item) {

                                return item.month;

                            }
                        ),


                    datasets: [

                        {

                            label: 'Sales',

                            data:
                                yearChartData.map(
                                    function(item) {

                                        return item.sales;

                                    }
                                ),

                            borderWidth: 1

                        },


                        {

                            label: 'Purchases',

                            data:
                                yearChartData.map(
                                    function(item) {

                                        return item.purchases;

                                    }
                                ),

                            borderWidth: 1

                        },


                        {

                            label: 'Profit',

                            data:
                                yearChartData.map(
                                    function(item) {

                                        return item.profit;

                                    }
                                ),

                            borderWidth: 1

                        }

                    ]

                },


                options: {

                    responsive: true,

                    maintainAspectRatio: false,


                    interaction: {

                        intersect: false,

                        mode: 'index'

                    },


                    plugins: {

                        legend: {

                            display: true,

                            position: 'top'

                        },


                        tooltip: {

                            callbacks: {

                                label:
                                    function(context) {

                                        return (
                                            context.dataset.label +
                                            ': GHS ' +
                                            Number(
                                                context.raw
                                            ).toLocaleString(
                                                undefined,
                                                {
                                                    minimumFractionDigits: 2,
                                                    maximumFractionDigits: 2
                                                }
                                            )
                                        );

                                    }

                            }

                        }

                    },


                    scales: {

                        x: {

                            title: {

                                display: true,

                                text: 'Month'

                            },

                            stacked: false

                        },


                        y: {

                            beginAtZero: true,

                            title: {

                                display: true,

                                text: 'Amount (GHS)'

                            },


                            ticks: {

                                callback:
                                    function(value) {

                                        return 'GHS ' +
                                            Number(
                                                value
                                            ).toLocaleString();

                                    }

                            }

                        }

                    }

                }

            }
        );

    }
    </script>


    <script>
    /* =====================================================
       DASHBOARD MOBILE SCANNER CONNECTION
       Keeps the scanner session available while logged in.
    ===================================================== */
    (function () {
        var scannerToken = null;
        var statusTimer = null;
        var heartbeatTimer = null;
        var scannerRunning = false;

        function scannerStatusBox() {
            return document.getElementById('dashboardScannerStatus');
        }

        function setScannerStatus(message, connected) {
            var box = scannerStatusBox();
            var text = document.getElementById('dashboardScannerStatusText');
            if (text) text.textContent = message;
            if (box) box.classList.toggle('connected', !!connected);
            if (box) box.classList.add('show');

        }

        function getScannerUrl() {
            var host = window.location.hostname || 'localhost';
            var securePort = '8443';
            var protocol = 'https:';
            var detected = <?= json_encode($dashboardScannerIp) ?>;

            /* The phone must use the PC LAN address and HTTPS for camera access. */
            if (detected && (host === 'localhost' || host === '127.0.0.1' || host === '::1')) {
                host = detected;
            }

            if (!host || host === 'localhost' || host === '127.0.0.1' || host === '::1') {
                host = detected || 'YOUR-PC-WIFI-IP';
            }

            return 'https://' + host + ':8443/philynda/mobile_scanner.php';
        }

        window.dashboardOpenMobileScanner = function () {
            var url = getScannerUrl();
            var w = window.open(url, '_blank');
            if (!w) window.location.href = url;
        };

        function jsonFetch(url, options) {
            return fetch(url, Object.assign({ cache: 'no-store' }, options || {}))
                .then(function (response) {
                    return response.text().then(function (text) {
                        var data;
                        try {
                            data = JSON.parse(text);
                        } catch (e) {
                            throw new Error('Scanner API did not return JSON (HTTP ' + response.status + ').');
                        }
                        return { response: response, data: data };
                    });
                });
        }

        function checkExistingScanner() {
            return jsonFetch('assets/scripts/mobile_scanner_api.php?action=status&_=' + Date.now())
                .then(function (result) {
                    if (!result.response.ok || !result.data.success) {
                        setScannerStatus('Not connected', false);
                        return false;
                    }

                    if (!result.data.active || !result.data.token) {
                        setScannerStatus('Not connected', false);
                        return false;
                    }

                    scannerToken = String(result.data.token);
                    scannerRunning = true;

                    setScannerStatus(
                        result.data.paired ? 'Phone connected' : 'Waiting for phone...',
                        !!result.data.paired
                    );

                    startDashboardHeartbeat();
                    return true;
                })
                .catch(function (error) {
                    console.warn('Dashboard scanner status:', error);
                    setScannerStatus('Not connected', false);
                    return false;
                });
        }

        /* Scanner connection is created automatically by the active POS/products page. */
        window.dashboardStartMobileScanner = function () {
            checkExistingScanner();
        };

        function dashboardHeartbeat() {
            if (!scannerRunning || !scannerToken) return;

            jsonFetch(
                'assets/scripts/mobile_scanner_api.php?action=status&token=' +
                encodeURIComponent(scannerToken) + '&_=' + Date.now()
            )
            .then(function (result) {
                if (!result.response.ok || !result.data.success) {
                    scannerRunning = false;
                    scannerToken = null;
                    setScannerStatus(result.data.message || 'Scanner connection ended.', false);
                    return;
                }

                setScannerStatus(
                    result.data.paired ? 'Phone connected' : 'Waiting for phone...',
                    !!result.data.paired
                );
            })
            .catch(function (error) {
                console.warn('Dashboard scanner heartbeat:', error);
            });
        }

        function startDashboardHeartbeat() {
            if (heartbeatTimer) clearInterval(heartbeatTimer);
            heartbeatTimer = setInterval(dashboardHeartbeat, 60000);
            dashboardHeartbeat();
        }

        var dashboardScannerIpVisible = true;
        var dashboardScannerIp = <?= json_encode($dashboardScannerIp) ?>;

        function renderDashboardScannerIp() {
            var valueEl = document.getElementById('dashboardScannerIpValue');
            var toggle = document.getElementById('dashboardScannerIpToggle');

            if (!valueEl) return;

            var hasIp = !!dashboardScannerIp;
            if (!hasIp) {
                valueEl.textContent = 'Unavailable';
                if (toggle) toggle.style.display = 'none';
                return;
            }

            if (dashboardScannerIpVisible) {
                valueEl.textContent = dashboardScannerIp;
                if (toggle) {
                    toggle.innerHTML = '<span class="fa fa-eye-slash"></span> Hide IP';
                }
            } else {
                valueEl.textContent = '••••••••';
                if (toggle) {
                    toggle.innerHTML = '<span class="fa fa-eye"></span> Show IP';
                }
            }
        }

        window.toggleDashboardScannerIp = function () {
            dashboardScannerIpVisible = !dashboardScannerIpVisible;
            renderDashboardScannerIp();
        };

        window.dashboardStopMobileScanner = function () {
            var button = document.getElementById('dashboardScannerDisconnect');
            if (button) button.disabled = true;

            if (!scannerToken) {
                scannerRunning = false;
                setScannerStatus('Not connected', false);
                if (button) button.disabled = false;
                return;
            }

            jsonFetch('assets/scripts/mobile_scanner_api.php?action=stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'token=' + encodeURIComponent(scannerToken)
            })
            .then(function (result) {
                if (!result.data || result.data.success !== true) {
                    throw new Error((result.data && result.data.message) || 'Unable to disconnect the mobile scanner.');
                }

                if (heartbeatTimer) clearInterval(heartbeatTimer);
                if (statusTimer) clearInterval(statusTimer);
                heartbeatTimer = null;
                statusTimer = null;
                scannerRunning = false;
                scannerToken = null;
                setScannerStatus('Not connected', false);
            })
            .catch(function (error) {
                console.error('Dashboard scanner disconnect:', error);
                setScannerStatus(error.message || 'Unable to disconnect the mobile scanner.', false);
            })
            .finally(function () {
                if (button) button.disabled = false;
            });
        };

        renderDashboardScannerIp();

        /* Automatically restore the existing logged-in scanner session. */
        checkExistingScanner();
    })();
    </script>

</body>
<!-- Mirrored from mannatthemes.com/annex/vertical/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 25 Apr 2026 11:13:31 GMT -->

</html>