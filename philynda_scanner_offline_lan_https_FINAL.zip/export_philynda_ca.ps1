#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

$PermanentDir = 'C:\ProgramData\Philynda\certificates'
$CaKey = Join-Path $PermanentDir 'philynda-root-ca.key'
$CaCrt = Join-Path $PermanentDir 'philynda-root-ca.crt'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BackupDir = Join-Path $ScriptDir 'philynda-ca-backup'

Write-Host '=== Export Philynda permanent Root CA ===' -ForegroundColor Cyan

if (-not (Test-Path $CaKey) -or -not (Test-Path $CaCrt)) {
    throw "The permanent Philynda Root CA was not found in $PermanentDir. Run setup_philynda_https.bat first."
}

if (-not (Test-Path $BackupDir)) {
    New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
}

Copy-Item $CaKey (Join-Path $BackupDir 'philynda-root-ca.key') -Force
Copy-Item $CaCrt (Join-Path $BackupDir 'philynda-root-ca.crt') -Force

Write-Host ''
Write-Host "CA backup created at:" -ForegroundColor Green
Write-Host "  $BackupDir" -ForegroundColor White
Write-Host ''
Write-Host 'IMPORTANT:' -ForegroundColor Yellow
Write-Host '1. Keep the .key file private.'
Write-Host '2. Copy the entire philynda-ca-backup folder to the new PC.'
Write-Host '3. Run setup_philynda_https.bat on the new PC.'
Write-Host '4. Do NOT create a new Root CA on the new PC if you want existing phones to remain trusted.'
