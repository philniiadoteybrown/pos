@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo PHILYNDA LOCAL NETWORK DIAGNOSTIC
echo ============================================================
echo.

echo [PC IPv4 addresses]
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-NetIPAddress -AddressFamily IPv4 ^| Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } ^| Select-Object InterfaceAlias,IPAddress,PrefixLength ^| Format-Table -AutoSize"

echo.
echo [Apache config test]
"C:\xampp\apache\bin\httpd.exe" -t

echo.
echo [Port 80 listeners]
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -State Listen -LocalPort 80 -ErrorAction SilentlyContinue ^| Format-Table -AutoSize"

echo.
echo [Port 8443 listeners]
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -State Listen -LocalPort 8443 -ErrorAction SilentlyContinue ^| Format-Table -AutoSize"

echo.
echo [Philynda firewall rule]
netsh advfirewall firewall show rule name="Philynda HTTPS 8443"

echo.
echo If the phone cannot open the PC URL while both devices are on the same
 echo Wi-Fi, check that the router does not have AP/client isolation enabled.
echo.
pause
