PHILYNDA MOBILE SCANNER - OFFLINE + PC MIGRATION SAFE HTTPS
============================================================

IMPORTANT FIX IN THIS VERSION
------------------------------
The previous setup could fail at Root CA creation when the XAMPP/OpenSSL
installation could not load its default openssl.cnf. This version creates and
passes an explicit OpenSSL configuration for the Root CA, and launches OpenSSL
through a process wrapper that uses the real exit code. This avoids Windows
PowerShell treating OpenSSL RSA progress text on STDERR as a NativeCommandError.

FIRST PC
--------
1. Copy the Philynda application into C:\xampp\htdocs\philynda.
2. Run setup_philynda_https.bat as Administrator.
3. If it succeeds, restart Apache from XAMPP.
4. Open the HTTPS scanner URL printed by the script.
5. Install philynda-root-ca.crt on each scanner phone once.
6. Use the PC's Wi-Fi/LAN IP from the dashboard.

OFFLINE
-------
After setup, the scanner does not need Internet access. The PC and phone must
only be connected to the same local Wi-Fi/Ethernet network.

PHONE
-----
DO NOT run BAT files on the phone.
The phone only needs the Root CA certificate installed once.

MIGRATION
---------
The Root CA is intended to be reusable between PCs. Keep the portable
philynda-ca-backup folder secure. On a NEW PC, copy the folder next to this
BAT/PS1 and run setup_philynda_https.bat. The new PC gets a new server
certificate for its current LAN IP while keeping the same Root CA.

SECURITY
--------
Never distribute philynda-root-ca.key to client phones. Do not publish it.
For separate client deployments, use a separate CA per client.

DIAGNOSTICS
-----------
If setup fails during certificate creation, inspect:
C:\xampp\apache\conf\philynda-ssl\openssl-last-error.log
The console now reports the actual OpenSSL error instead of hiding it behind a
generic "Unable to create the Philynda Root CA certificate" message.

ROLLBACK
--------
If Apache does not start after HTTPS configuration, stop Apache and run:
rollback_philynda_https.bat


LOCALHOST vs LAN IP FIX
-----------------------
The scanner session is stored server-side in mobile_scanner_sessions/.
A browser can have separate PHP sessions for localhost and the PC LAN IP.
The supplied mobile_scanner_api.php now exposes a desktop status/resume action
and reuses the active server session when you switch between those local
addresses. This prevents the dashboard from saying "Not connected" merely
because you opened Philynda through a different local hostname/IP.

OFFLINE ROUTER
--------------
The application does not require Internet access for scanner operation.
The PC and phone only need to be able to reach each other on the same local
Wi-Fi/Ethernet network. If a phone cannot open the PC's LAN address at all,
check that the Wi-Fi network does not have client/AP isolation enabled and
that Windows Firewall allows the Philynda HTTP/HTTPS port.

IMPORTANT
---------
Run the BAT files only on the Windows XAMPP PC. No BAT file is run on a phone.
Install only philynda-root-ca.crt on the phone; never install or distribute
philynda-root-ca.key.


NETWORK DIAGNOSTIC
------------------
If the phone cannot reach the PC on the local Wi-Fi, run
check_philynda_network.bat on the Windows PC. It shows LAN IPv4 addresses,
Apache status, ports 80/8443, and the Philynda firewall rule.
