#requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'
$ApacheConf = 'C:\xampp\apache\conf'
$HttpdConf = Join-Path $ApacheConf 'httpd.conf'
$Backup = Join-Path $ApacheConf 'httpd.conf.philynda-backup'
$VhostConf = Join-Path $ApacheConf 'extra\httpd-philynda-ssl.conf'
if (Test-Path $Backup) {
    Copy-Item $Backup $HttpdConf -Force
    Write-Host 'Restored httpd.conf from the Philynda backup.' -ForegroundColor Green
} else {
    Write-Host 'Backup not found; no httpd.conf changes were made.' -ForegroundColor Yellow
}
if (Test-Path $VhostConf) { Remove-Item $VhostConf -Force }
& netsh advfirewall firewall delete rule name='Philynda HTTPS 8443' | Out-Host
& 'C:\xampp\apache\bin\httpd.exe' -t
Write-Host 'Rollback complete. Restart Apache from the XAMPP Control Panel.' -ForegroundColor Cyan
