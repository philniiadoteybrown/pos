<?php
/*
 * Remote mobile barcode scanner.
 *
 * The scanner no longer requires a pairing code. When this page is loaded,
 * it checks the local POS scanner-session folder for the currently active
 * desktop session and passes that token into the page. This avoids relying
 * only on a browser AJAX discovery request.
 */

$initialScannerToken = '';
$scannerSessionDir = __DIR__ . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'scripts' . DIRECTORY_SEPARATOR . 'mobile_scanner_sessions';

if (is_dir($scannerSessionDir)) {
    $files = glob($scannerSessionDir . DIRECTORY_SEPARATOR . '*.json');

    if ($files) {
        $now = time();
        $latestCreated = 0;

        foreach ($files as $file) {
            $raw = @file_get_contents($file);
            if ($raw === false || trim($raw) === '') {
                continue;
            }

            $data = json_decode($raw, true);
            if (!is_array($data)) {
                continue;
            }

            if (empty($data['active'])) {
                continue;
            }

            $expiresAt = (int)($data['expires_at'] ?? 0);
            if ($expiresAt > 0 && $expiresAt < $now) {
                @unlink($file);
                continue;
            }

            $token = preg_replace('/[^a-f0-9]/i', '', (string)($data['token'] ?? ''));
            if (strlen($token) !== 48) {
                continue;
            }

            $createdAt = (int)($data['created_at'] ?? 0);
            if ($createdAt >= $latestCreated) {
                $latestCreated = $createdAt;
                $initialScannerToken = $token;
            }
        }
    }
}


$mobileScannerServerIp = '';
$serverAddr = isset($_SERVER['SERVER_ADDR']) ? trim((string)$_SERVER['SERVER_ADDR']) : '';
if (filter_var($serverAddr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && strpos($serverAddr, '127.') !== 0) {
    $mobileScannerServerIp = $serverAddr;
}

if ($mobileScannerServerIp === '') {
    $hostName = gethostname();
    if ($hostName) {
        $hostIps = @gethostbynamel($hostName);
        if (is_array($hostIps)) {
            foreach ($hostIps as $candidateIp) {
                $candidateIp = trim((string)$candidateIp);
                if (!filter_var($candidateIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    continue;
                }
                if (strpos($candidateIp, '127.') === 0 || strpos($candidateIp, '169.254.') === 0) {
                    continue;
                }
                $parts = array_map('intval', explode('.', $candidateIp));
                if ($parts[0] === 10 ||
                    ($parts[0] === 172 && $parts[1] >= 16 && $parts[1] <= 31) ||
                    ($parts[0] === 192 && $parts[1] === 168)) {
                    $mobileScannerServerIp = $candidateIp;
                    break;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Mobile Barcode Scanner</title>

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            margin: 0;
            padding: 0;
            width: 100%;
            min-height: 100%;
            background: #111;
            color: #fff;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
        }

        .scanner-app {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .scanner-header {
            padding: 14px 16px;
            background: #000;
            text-align: center;
            flex-shrink: 0;
        }

        .scanner-header h1 {
            margin: 0;
            font-size: 21px;
        }

        .scanner-header p {
            margin: 5px 0 0;
            color: #bdbdbd;
            font-size: 12px;
        }

        .connection-panel {
            width: min(92vw, 440px);
            margin: 18px auto;
            padding: 18px;
            background: #1f1f1f;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,.35);
        }

        .connection-panel h2 {
            margin: 0 0 8px;
            font-size: 18px;
        }

        .connection-panel p {
            margin: 0 0 14px;
            color: #c9c9c9;
            font-size: 13px;
            line-height: 1.45;
        }

        .pair-input {
            width: 100%;
            height: 54px;
            border: 1px solid #555;
            border-radius: 8px;
            background: #fff;
            color: #111;
            font-size: 28px;
            letter-spacing: 7px;
            text-align: center;
            font-weight: 800;
            outline: none;
        }

        .pair-input:focus {
            border-color: #0d6efd;
        }

        .connect-btn {
            width: 100%;
            min-height: 50px;
            margin-top: 10px;
            border: 0;
            border-radius: 8px;
            background: #0d6efd;
            color: #fff;
            font-size: 17px;
            font-weight: 700;
        }

        .status {
            margin-top: 12px;
            padding: 10px;
            background: #2a2a2a;
            border-radius: 7px;
            text-align: center;
            font-size: 13px;
        }

        .scanner-area {
            display: none;
            flex: 1;
            flex-direction: column;
            min-height: 0;
        }

        .scanner-status-bar {
            padding: 9px 12px;
            background: #1a1a1a;
            font-size: 13px;
            text-align: center;
        }

        .scanner-camera {
            position: relative;
            flex: 1;
            min-height: 60vh;
            background: #000;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        #mobileBarcodeReader {
            width: 100%;
            max-width: 900px;
        }

        #mobileBarcodeReader video {
            width: 100% !important;
            height: auto !important;
            object-fit: cover;
        }

        .last-scan {
            padding: 12px;
            background: #111;
            text-align: center;
            flex-shrink: 0;
        }

        .last-scan-label {
            font-size: 11px;
            color: #999;
            margin-bottom: 3px;
        }

        #lastBarcode {
            font-size: 19px;
            font-weight: 700;
            word-break: break-all;
        }

        .scanner-actions {
            padding: 10px 12px 14px;
            background: #111;
            display: flex;
            gap: 8px;
            flex-shrink: 0;
        }

        .scanner-actions button {
            flex: 1;
            min-height: 46px;
            border: 0;
            border-radius: 7px;
            font-size: 14px;
            font-weight: 700;
        }

        .disconnect-btn {
            background: #dc3545;
            color: #fff;
        }

        .photo-scan-btn {
            background: #6f42c1;
            color: #fff;
        }

        .scan-again-btn {
            background: #198754;
            color: #fff;
        }

        .hidden {
            display: none !important;
        }

        @media (orientation: landscape) {
            .scanner-camera {
                min-height: 68vh;
            }

            .scan-guide {
                top: 34%;
                height: 105px;
            }
        }
    </style>
</head>

<body>

<div class="scanner-app">

    <div class="scanner-header">
        <h1>📱 Mobile Barcode Scanner</h1>
        <p>Scan products and send the barcode directly to the desktop POS.</p>
    </div>

    <div id="connectionPanel" class="connection-panel">

        <h2>Connect to Desktop POS</h2>

        <p>
            This scanner connects automatically to the active POS on this same server.
            No pairing code is required.
        </p>

        <button
            type="button"
            class="connect-btn"
            id="connectButton"
            onclick="autoConnectScanner(true)">
            🔄 Find POS Automatically
        </button>

        <div id="connectionStatus" class="status">
            Looking for an active desktop POS scanner...
        </div>

    </div>

    <div id="scannerArea" class="scanner-area">

        <div id="scannerStatus" class="scanner-status-bar">
            Starting camera...
        </div>

        <div class="scanner-camera">

            <div id="mobileBarcodeReader"></div>
</div>

        </div>

        <div class="last-scan">
            <div class="last-scan-label">
                Last barcode sent
            </div>

            <div id="lastBarcode">
                —
            </div>
        </div>

        <div class="scanner-actions">

            <button
                type="button"
                class="scan-again-btn"
                onclick="restartCamera()">
                Restart Camera
            </button>

            <button
                type="button"
                class="photo-scan-btn"
                onclick="openPhotoScan()">
                Photo Scan
            </button>

            <button
                type="button"
                class="disconnect-btn"
                onclick="disconnectScanner()">
                Disconnect
            </button>

        </div>

    </div>

</div>
<div id="photoScanHiddenTarget" class="hidden"></div>
<input id="photoScanInput" type="file" accept="image/*" capture="environment" class="hidden">

<script src="assets/scripts/html5-qrcode.min.js"></script>

<script>
'use strict';

const SCANNER_API = new URL('assets/scripts/mobile_scanner_api.php', window.location.href).toString();
const INITIAL_SCANNER_TOKEN = <?= json_encode($initialScannerToken); 

$mobileScannerServerIp = '';
$serverAddr = isset($_SERVER['SERVER_ADDR']) ? trim((string)$_SERVER['SERVER_ADDR']) : '';
if (filter_var($serverAddr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && strpos($serverAddr, '127.') !== 0) {
    $mobileScannerServerIp = $serverAddr;
}

if ($mobileScannerServerIp === '') {
    $hostName = gethostname();
    if ($hostName) {
        $hostIps = @gethostbynamel($hostName);
        if (is_array($hostIps)) {
            foreach ($hostIps as $candidateIp) {
                $candidateIp = trim((string)$candidateIp);
                if (!filter_var($candidateIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                    continue;
                }
                if (strpos($candidateIp, '127.') === 0 || strpos($candidateIp, '169.254.') === 0) {
                    continue;
                }
                $parts = array_map('intval', explode('.', $candidateIp));
                if ($parts[0] === 10 ||
                    ($parts[0] === 172 && $parts[1] >= 16 && $parts[1] <= 31) ||
                    ($parts[0] === 192 && $parts[1] === 168)) {
                    $mobileScannerServerIp = $candidateIp;
                    break;
                }
            }
        }
    }
}
?>;
let mobileScanner = null;
let mobileScannerRunning = false;
let mobileScannerToken = '';
let lastMobileBarcode = '';
let lastMobileBarcodeTime = 0;
let autoConnectTimer = null;
let autoConnectAttempts = 0;
let scanRequestInProgress = false;

function setConnectionStatus(message) {
    const el = document.getElementById('connectionStatus');
    if (el) el.textContent = message;
}

function setScannerStatus(message) {
    const el = document.getElementById('scannerStatus');
    if (el) el.textContent = message;
}

async function apiJson(url, options = {}) {
    const response = await fetch(url, {
        cache: 'no-store',
        ...options
    });

    const text = await response.text();
    let data;

    try {
        data = JSON.parse(text);
    } catch (e) {
        throw new Error('The scanner API did not return JSON. Check the PHP API path and server errors.');
    }

    if (!response.ok && !data.message) {
        data.message = 'Scanner request failed (HTTP ' + response.status + ').';
    }

    return { response, data };
}

async function connectWithToken(token) {
    token = String(token || '').trim();

    if (!token) {
        throw new Error('No scanner session token is available.');
    }

    const connectUrl =
        SCANNER_API +
        '?action=connect&token=' +
        encodeURIComponent(token) +
        '&device=' +
        encodeURIComponent(navigator.userAgent.substring(0, 100)) +
        '&_=' +
        Date.now();

    const connectResult = await apiJson(
        connectUrl,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: new URLSearchParams({
                token: token,
                device: navigator.userAgent.substring(0, 100)
            })
        }
    );

    if (!connectResult.response.ok || !connectResult.data.success) {
        const err = new Error(
            connectResult.data.message ||
            ('Automatic connection failed (HTTP ' + connectResult.response.status + ').')
        );
        err.httpStatus = connectResult.response.status;
        throw err;
    }

    mobileScannerToken = String(connectResult.data.token || token).trim();
    sessionStorage.setItem('mobileScannerToken', mobileScannerToken);

    document.getElementById('connectionPanel').style.display = 'none';
    document.getElementById('scannerArea').style.display = 'flex';
    setScannerStatus('Connected automatically. Requesting camera permission...');

    await startCamera();
}

async function autoConnectScanner(manualRetry) {
    clearTimeout(autoConnectTimer);

    const button = document.getElementById('connectButton');
    if (button) button.disabled = true;

    if (manualRetry) {
        autoConnectAttempts = 0;
        setConnectionStatus('Looking for the active desktop POS scanner...');
    }

    try {
        /*
         * Always ask the current server for the active POS session first.
         * This prevents an old token left in the phone browser from being
         * used after the POS has been moved/restarted on another PC.
         */
        let lastError = null;

        const result = await apiJson(
            SCANNER_API + '?action=discover&_=' + Date.now(),
            { method: 'GET' }
        );

        if (result.data && result.data.success && result.data.token) {
            try {
                await connectWithToken(result.data.token);
                return;
            } catch (error) {
                lastError = error;
            }
        }

        /*
         * If discovery did not return a session, only then try the token
         * embedded in this page. This is useful when the page was generated
         * immediately after the desktop created its session.
         */
        if (INITIAL_SCANNER_TOKEN) {
            try {
                await connectWithToken(INITIAL_SCANNER_TOKEN);
                return;
            } catch (error) {
                lastError = error;
            }
        }

        /*
         * Do not use a stale sessionStorage token as the primary connection.
         * Remove it if it exists; a future successful connection will replace it.
         */
        sessionStorage.removeItem('mobileScannerToken');

        autoConnectAttempts++;

        if (result.response && result.response.status === 404) {
            setConnectionStatus('No active POS scanner yet. Start Mobile Scanner on the desktop POS...');
        } else if (lastError) {
            setConnectionStatus(lastError.message || 'Could not connect to the desktop POS.');
        } else {
            setConnectionStatus(
                (result.data && result.data.message) ||
                'No active POS scanner was found.'
            );
        }

        /* Keep trying indefinitely. The phone can be opened before the PC starts the scanner. */
        autoConnectTimer = setTimeout(function() {
            autoConnectScanner(false);
        }, 2000);

    } catch (error) {
        console.error('AUTO CONNECT ERROR:', error);
        autoConnectAttempts++;

        setConnectionStatus(
            'Could not reach the POS server: ' +
            (error.message || 'Network request failed.') +
            ' Retrying...'
        );

        autoConnectTimer = setTimeout(function() {
            autoConnectScanner(false);
        }, 2000);
    } finally {
        if (button) button.disabled = false;
    }
}

function chooseRearCamera(cameras) {
    if (!Array.isArray(cameras) || cameras.length === 0) return null;

    for (let i = 0; i < cameras.length; i++) {
        const label = String(cameras[i].label || '').toLowerCase();
        if (label.indexOf('back') !== -1 || label.indexOf('rear') !== -1 || label.indexOf('environment') !== -1) {
            return cameras[i];
        }
    }

    return cameras[cameras.length - 1];
}

async function startCamera() {
    if (!mobileScannerToken) {
        mobileScannerToken = sessionStorage.getItem('mobileScannerToken') || '';
    }

    if (!mobileScannerToken) {
        setScannerStatus('No active POS connection. Return to the connection screen and retry.');
        return;
    }

    if (typeof Html5Qrcode === 'undefined') {
        setScannerStatus('Barcode scanner library could not be loaded. Check assets/scripts/html5-qrcode.min.js.');
        return;
    }

    await stopCamera();

    try {
        if (!window.isSecureContext || window.location.protocol !== 'https:') {
            throw new Error(
                'Live camera scanning requires HTTPS. Open the secure mobile scanner address: ' +
                <?= json_encode('https://' . ($mobileScannerServerIp ?: 'YOUR-PC-WIFI-IP') . ':8443/philynda/mobile_scanner.php'); ?>
            );
        }

        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error(
                'This browser does not expose camera access on this page. The secure HTTPS scanner address is required.'
            );
        }

        mobileScanner = new Html5Qrcode('mobileBarcodeReader', { verbose: false });

        const cameras = await Html5Qrcode.getCameras();
        if (!cameras || cameras.length === 0) {
            throw new Error('No camera was found on this phone.');
        }

        const selectedCamera = chooseRearCamera(cameras);
        if (!selectedCamera) throw new Error('No usable camera was found.');

        const config = {
            fps: 10,
            qrbox: function(viewfinderWidth, viewfinderHeight) {
                const width = Math.max(180, Math.floor(viewfinderWidth * 0.88));
                const height = Math.max(90, Math.min(160, Math.floor(viewfinderHeight * 0.24)));
                return {
                    width: Math.min(width, viewfinderWidth),
                    height: Math.min(height, viewfinderHeight)
                };
            },
            aspectRatio: 1.7777778
        };

        if (typeof Html5QrcodeSupportedFormats !== 'undefined') {
            config.formatsToSupport = [
                Html5QrcodeSupportedFormats.CODE_128,
                Html5QrcodeSupportedFormats.CODE_39,
                Html5QrcodeSupportedFormats.CODE_93,
                Html5QrcodeSupportedFormats.EAN_13,
                Html5QrcodeSupportedFormats.EAN_8,
                Html5QrcodeSupportedFormats.UPC_A,
                Html5QrcodeSupportedFormats.UPC_E,
                Html5QrcodeSupportedFormats.ITF,
                Html5QrcodeSupportedFormats.CODABAR
            ];
        }

        await mobileScanner.start(
            selectedCamera.id,
            config,
            function(decodedText) {
                const barcode = String(decodedText || '').trim();
                if (!barcode) return;

                const now = Date.now();
                if (barcode === lastMobileBarcode && now - lastMobileBarcodeTime < 1500) {
                    return;
                }

                lastMobileBarcode = barcode;
                lastMobileBarcodeTime = now;
                sendBarcodeToDesktop(barcode);
            },
            function() {}
        );

        mobileScannerRunning = true;
        setScannerStatus('Connected. Point the camera at a barcode.');

    } catch (error) {
        console.error('CAMERA START ERROR:', error);
        setScannerStatus('Unable to start camera: ' + error.message + ' Allow camera access and try again.');
    }
}

async function sendBarcodeToDesktop(barcode) {
    if (scanRequestInProgress) return;

    if (!mobileScannerToken) {
        mobileScannerToken = sessionStorage.getItem('mobileScannerToken') || '';
    }

    if (!mobileScannerToken) {
        setScannerStatus('Desktop connection is missing. Reconnect automatically.');
        autoConnectScanner(true);
        return;
    }

    scanRequestInProgress = true;

    const lastBarcode = document.getElementById('lastBarcode');
    if (lastBarcode) lastBarcode.textContent = barcode;
    setScannerStatus('Sending barcode...');

    try {
        const result = await apiJson(SCANNER_API + '?action=scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            body: new URLSearchParams({
                token: mobileScannerToken,
                barcode: barcode
            })
        });

        if (!result.response.ok || !result.data.success) {
            if (result.response.status === 404 || result.response.status === 409 || result.response.status === 410) {
                mobileScannerToken = '';
                sessionStorage.removeItem('mobileScannerToken');
                await stopCamera();
                document.getElementById('scannerArea').style.display = 'none';
                document.getElementById('connectionPanel').style.display = 'block';
                setConnectionStatus('Desktop scanner connection ended. Reconnecting...');
                autoConnectScanner(false);
            } else {
                setScannerStatus(result.data.message || 'Barcode could not be sent to the desktop POS.');
            }
            return;
        }

        setScannerStatus('Barcode sent. Ready for the next scan.');
    } catch (error) {
        console.error('SEND BARCODE ERROR:', error);
        setScannerStatus('Could not reach the desktop server: ' + (error.message || 'Network request failed.'));
    } finally {
        scanRequestInProgress = false;
    }
}


function openPhotoScan() {
    const input = document.getElementById('photoScanInput');
    if (!input) return;
    input.value = '';
    input.click();
}

async function handlePhotoScan(event) {
    const input = event.target;
    const file = input && input.files ? input.files[0] : null;
    if (!file) return;

    if (typeof Html5Qrcode === 'undefined') {
        setScannerStatus('Barcode scanner library could not be loaded.');
        return;
    }

    try {
        setScannerStatus('Reading barcode from photo...');
        const fileScanner = new Html5Qrcode('photoScanHiddenTarget', { verbose: false });
        const decoded = await fileScanner.scanFile(file, true);

        try { await fileScanner.clear(); } catch (e) {}

        const barcode = String(decoded || '').trim();
        if (!barcode) {
            setScannerStatus('No barcode found in the photo. Try again.');
            return;
        }

        const now = Date.now();
        if (barcode === lastMobileBarcode && now - lastMobileBarcodeTime < 1500) {
            setScannerStatus('Same barcode already scanned. Ready for the next scan.');
            return;
        }

        lastMobileBarcode = barcode;
        lastMobileBarcodeTime = now;
        await sendBarcodeToDesktop(barcode);
    } catch (error) {
        console.error('PHOTO SCAN ERROR:', error);
        setScannerStatus('Photo scan could not read a barcode. Use a clear, close-up photo.');
    } finally {
        if (input) input.value = '';
    }
}

async function restartCamera() {
    setScannerStatus('Restarting camera...');
    await startCamera();
}

async function stopCamera() {
    if (!mobileScanner) return;

    try {
        if (mobileScannerRunning) {
            await mobileScanner.stop();
        }
    } catch (error) {
        console.warn('CAMERA STOP WARNING:', error);
    } finally {
        mobileScannerRunning = false;
        try {
            await mobileScanner.clear();
        } catch (error) {}
        mobileScanner = null;
    }
}

async function disconnectScanner() {
    clearTimeout(autoConnectTimer);
    await stopCamera();

    const token = mobileScannerToken || sessionStorage.getItem('mobileScannerToken') || '';

    if (token) {
        try {
            await apiJson(SCANNER_API + '?action=stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({ token: token })
            });
        } catch (error) {
            console.warn('MOBILE SCANNER DISCONNECT WARNING:', error);
        }
    }

    mobileScannerToken = '';
    sessionStorage.removeItem('mobileScannerToken');
    lastMobileBarcode = '';
    lastMobileBarcodeTime = 0;

    document.getElementById('scannerArea').style.display = 'none';
    document.getElementById('connectionPanel').style.display = 'block';
    setConnectionStatus('Disconnected. Tap Find POS Automatically to reconnect.');
}

document.addEventListener('DOMContentLoaded', function() {
    var photoInput = document.getElementById('photoScanInput');
    if (photoInput) photoInput.addEventListener('change', handlePhotoScan);
    autoConnectScanner(false);
});

window.addEventListener('beforeunload', function() {
    try {
        if (mobileScanner && mobileScannerRunning) {
            mobileScanner.stop();
        }
    } catch (error) {}
});
</script>

</body>
</html>
