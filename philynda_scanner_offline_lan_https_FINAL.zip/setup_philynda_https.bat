@echo off
setlocal
cd /d "%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Write-Host 'Philynda HTTPS setup - Administrator check' -ForegroundColor Cyan; if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Write-Host 'Please right-click this BAT file and choose Run as administrator.' -ForegroundColor Red; exit 1 }"
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_philynda_https.ps1"
if errorlevel 1 (
  echo.
  echo ============================================================
  echo Philynda HTTPS setup FAILED.
  echo If OpenSSL failed, inspect:
  echo C:\xampp\apache\conf\philynda-ssl\openssl-last-error.log
  echo ============================================================
  echo.
  pause
  exit /b 1
)

echo.
echo Setup completed. Restart Apache in XAMPP, then use the HTTPS URL shown above.
echo This setup is designed for offline local-network operation; Internet is not required.
pause
