@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0export_philynda_ca.ps1"
if errorlevel 1 (
  echo.
  echo Philynda CA export failed. Review the message above.
  pause
  exit /b 1
)
echo.
pause
